import express, { type NextFunction, type Request, type Response } from 'express';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { db, migrate } from './lib/db.js';

const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '25mb' }));
app.use((_req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  next();
});

migrate(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    username TEXT NOT NULL UNIQUE COLLATE NOCASE,
    password_hash TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS user_sessions (
    token TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    expires_at INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS brokers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    handle TEXT NOT NULL UNIQUE COLLATE NOCASE,
    active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS employees (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    handle TEXT NOT NULL UNIQUE COLLATE NOCASE,
    employee_code TEXT UNIQUE,
    verification_code TEXT UNIQUE,
    department TEXT NOT NULL DEFAULT 'عملیات',
    position_title TEXT NOT NULL DEFAULT 'کارمند',
    status TEXT NOT NULL DEFAULT 'فعال',
    public_visible INTEGER NOT NULL DEFAULT 1,
    public_status_reason TEXT,
    started_at TEXT,
    notes TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS uploaded_files (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    filename TEXT NOT NULL UNIQUE,
    original_name TEXT,
    mime_type TEXT NOT NULL,
    size INTEGER NOT NULL,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    admin_username TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS conversations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    subject TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'جدید',
    unread_user INTEGER NOT NULL DEFAULT 0,
    unread_admin INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    conversation_id INTEGER NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
    sender TEXT NOT NULL CHECK(sender IN ('user','admin')),
    body TEXT NOT NULL,
    attachment_url TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS notices (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    body TEXT NOT NULL,
    active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS admin_tokens (
    token TEXT PRIMARY KEY,
    username TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'owner',
    expires_at INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS activity_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    admin_username TEXT NOT NULL,
    action TEXT NOT NULL,
    details TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS internal_notes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    conversation_id INTEGER NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
    admin_username TEXT NOT NULL,
    body TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS admin_login_attempts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL,
    success INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS verification_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    broker_id INTEGER NOT NULL REFERENCES brokers(id) ON DELETE CASCADE,
    previous_status TEXT,
    new_status TEXT NOT NULL,
    admin_username TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS discrepancy_reports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    handle TEXT NOT NULL,
    report_type TEXT NOT NULL,
    description TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'دریافت شد',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS partner_applications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    application_code TEXT UNIQUE,
    name TEXT NOT NULL,
    handle TEXT NOT NULL COLLATE NOCASE,
    cooperation_type TEXT NOT NULL,
    department TEXT NOT NULL,
    experience TEXT NOT NULL,
    description TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'دریافت شد',
    priority TEXT NOT NULL DEFAULT 'عادی',
    assignee TEXT,
    internal_note TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS admin_notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    body TEXT NOT NULL,
    target TEXT NOT NULL,
    is_read INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS broker_violations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    broker_id INTEGER NOT NULL REFERENCES brokers(id) ON DELETE RESTRICT,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'در حال بررسی',
    evidence_url TEXT,
    public_note TEXT,
    internal_note TEXT,
    public_visible INTEGER NOT NULL DEFAULT 1,
    created_by TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
`);

const additiveColumns = [
  'ALTER TABLE users ADD COLUMN status TEXT NOT NULL DEFAULT \'فعال\'',
  'ALTER TABLE users ADD COLUMN last_activity TEXT',
  'ALTER TABLE brokers ADD COLUMN verification_code TEXT',
  'ALTER TABLE brokers ADD COLUMN verification_status TEXT NOT NULL DEFAULT \'فعال\'',
  'ALTER TABLE brokers ADD COLUMN verification_level INTEGER NOT NULL DEFAULT 4',
  'ALTER TABLE brokers ADD COLUMN cooperation_type TEXT NOT NULL DEFAULT \'واسطه\'',
  'ALTER TABLE brokers ADD COLUMN updated_at TEXT',
  'ALTER TABLE brokers ADD COLUMN partner_code TEXT',
  'ALTER TABLE brokers ADD COLUMN category TEXT NOT NULL DEFAULT \'واسطه‌گری\'',
  'ALTER TABLE brokers ADD COLUMN public_visible INTEGER NOT NULL DEFAULT 1',
  'ALTER TABLE brokers ADD COLUMN last_review TEXT',
  'ALTER TABLE brokers ADD COLUMN qr_active INTEGER NOT NULL DEFAULT 1',
  'ALTER TABLE brokers ADD COLUMN activity_type TEXT NOT NULL DEFAULT \'واسطه‌گری\'',
  'ALTER TABLE brokers ADD COLUMN position_title TEXT NOT NULL DEFAULT \'واسطه‌گری\'',
  'ALTER TABLE brokers ADD COLUMN cooperation_status TEXT NOT NULL DEFAULT \'فعال\'',
  'ALTER TABLE brokers ADD COLUMN status_reason TEXT',
  'ALTER TABLE brokers ADD COLUMN status_notes TEXT',
  'ALTER TABLE brokers ADD COLUMN status_started_at TEXT',
  'ALTER TABLE brokers ADD COLUMN status_ends_at TEXT',
  'ALTER TABLE brokers ADD COLUMN status_applied_by TEXT',
  'ALTER TABLE brokers ADD COLUMN public_status_reason INTEGER NOT NULL DEFAULT 0',
  'ALTER TABLE brokers ADD COLUMN verification_notes TEXT',
  'ALTER TABLE brokers ADD COLUMN verification_reviewed_by TEXT',
  'ALTER TABLE brokers ADD COLUMN official_contact TEXT',
  'ALTER TABLE brokers ADD COLUMN deleted_at TEXT',
  'ALTER TABLE brokers ADD COLUMN deleted_by TEXT',
  'ALTER TABLE brokers ADD COLUMN deletion_reason TEXT',
  'ALTER TABLE verification_history ADD COLUMN reason TEXT',
  'ALTER TABLE verification_history ADD COLUMN notes TEXT',
  'ALTER TABLE verification_history ADD COLUMN starts_at TEXT',
  'ALTER TABLE verification_history ADD COLUMN ends_at TEXT',
  'ALTER TABLE verification_history ADD COLUMN duration_label TEXT',
  'ALTER TABLE conversations ADD COLUMN ticket_code TEXT',
  'ALTER TABLE conversations ADD COLUMN priority TEXT NOT NULL DEFAULT \'عادی\'',
  'ALTER TABLE conversations ADD COLUMN department TEXT NOT NULL DEFAULT \'پشتیبانی\'',
  'ALTER TABLE conversations ADD COLUMN assignee TEXT'
];
for (const statement of additiveColumns) {
  try { db.exec(statement); } catch (error) { if (!String(error).includes('duplicate column')) console.error('Schema extension failed', { statement, error }); }
}

const employeeAdditiveColumns = [
  "ALTER TABLE employees ADD COLUMN employee_code TEXT",
  "ALTER TABLE employees ADD COLUMN verification_code TEXT",
  "ALTER TABLE employees ADD COLUMN department TEXT NOT NULL DEFAULT 'عملیات'",
  "ALTER TABLE employees ADD COLUMN position_title TEXT NOT NULL DEFAULT 'کارمند'",
  "ALTER TABLE employees ADD COLUMN status TEXT NOT NULL DEFAULT 'فعال'",
  "ALTER TABLE employees ADD COLUMN public_visible INTEGER NOT NULL DEFAULT 1",
  "ALTER TABLE employees ADD COLUMN public_status_reason TEXT",
  "ALTER TABLE employees ADD COLUMN started_at TEXT",
  "ALTER TABLE employees ADD COLUMN notes TEXT",
  "ALTER TABLE employees ADD COLUMN updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP"
];
for (const statement of employeeAdditiveColumns) {
  try { db.exec(statement); } catch (error) { if (!String(error).includes('duplicate column')) console.error('Employee schema extension failed', { statement, error }); }
}
db.prepare("UPDATE brokers SET verification_status=CASE verification_status WHEN 'فعال' THEN 'تأییدشده' WHEN 'تأییدشده داخلی' THEN 'تأییدشده' WHEN 'نیازمند بروزرسانی' THEN 'نیازمند بررسی مجدد' WHEN 'تعلیق‌شده' THEN 'تعلیق اعتبار' ELSE verification_status END").run();
db.prepare("UPDATE brokers SET activity_type=COALESCE(NULLIF(activity_type,''),cooperation_type,'واسطه‌گری'),position_title=COALESCE(NULLIF(position_title,''),cooperation_type,'واسطه‌گری'),cooperation_status=COALESCE(NULLIF(cooperation_status,''),'فعال')").run();

const brokerSeeds = [
  ['گل نرگس', '@GoLL_NaRGeS_Bia31'], ['جنگی', '@Mr_JaNGi'], ['ویدکس', '@ViDeX_AMiR'],
  ['امیر الماس', '@AmiR_HP021'], ['اکبر', '@AkBaR_AhARi'], ['علی باقری', '@ALi_BaGheERi02'],
  ['رضا رستمی', '@ReZa_RosTaMi_999'], ['جوشکار', '@MR_JoShKaR'],
];
const brokerCount = db.prepare('SELECT COUNT(*) AS c FROM brokers').get() as { c: number };
if (brokerCount.c === 0) {
  const insert = db.prepare('INSERT INTO brokers (name, handle) VALUES (?, ?)');
  for (const item of brokerSeeds) insert.run(item[0], item[1]);
}
const brokersWithoutCode = db.prepare("SELECT id FROM brokers WHERE verification_code IS NULL OR verification_code = ''").all() as Array<{ id: number }>;
for (const broker of brokersWithoutCode) {
  db.prepare('UPDATE brokers SET verification_code=?,partner_code=?,last_review=CURRENT_TIMESTAMP WHERE id=?').run(`VRF-${new Date().getFullYear()}-${String(broker.id).padStart(6, '0')}`, `PART-${new Date().getFullYear()}-${String(broker.id).padStart(6, '0')}`, broker.id);
}
const brokersWithoutPartnerCode = db.prepare("SELECT id FROM brokers WHERE partner_code IS NULL OR partner_code = ''").all() as Array<{ id: number }>;
for (const broker of brokersWithoutPartnerCode) db.prepare('UPDATE brokers SET partner_code=?,last_review=COALESCE(last_review,CURRENT_TIMESTAMP) WHERE id=?').run(`PART-${new Date().getFullYear()}-${String(broker.id).padStart(6, '0')}`, broker.id);
db.prepare('UPDATE brokers SET updated_at=COALESCE(updated_at,CURRENT_TIMESTAMP),last_review=COALESCE(last_review,CURRENT_TIMESTAMP)').run();
db.prepare("UPDATE brokers SET public_visible=1,public_status_reason=1 WHERE cooperation_status='تعلیق‌شده' AND deleted_at IS NULL").run();

const categories = new Set(['پشتیبانی','گزارش تخلف','پیگیری درخواست','امور واسطه‌گری','عضویت در انجمن','مشکلات حساب کاربری','همکاری','سایر موارد']);
const statuses = new Set(['جدید','در حال بررسی','پاسخ داده شد','در انتظار پاسخ کاربر','بسته شد']);
const ADMIN_USERNAME = process.env.ADMIN_USERNAME || 'owner_vaseteh';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'Vst!9Qm#42Lk';
const SESSION_AGE = 7 * 24 * 60 * 60 * 1000;

function normalizeUsername(value: unknown): string {
  return String(value ?? '').trim().toLowerCase().replace(/[^a-z0-9_.-]/g, '');
}
function cleanText(value: unknown, max = 4000): string {
  return String(value ?? '').trim().slice(0, max);
}
function passwordHash(password: string, salt = crypto.randomBytes(16).toString('hex')): string {
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}
function verifyPassword(password: string, stored: string): boolean {
  try {
    const [salt, expectedHex] = stored.split(':');
    const actual = crypto.scryptSync(password, salt, 64);
    const expected = Buffer.from(expectedHex, 'hex');
    return actual.length === expected.length && crypto.timingSafeEqual(actual, expected);
  } catch { return false; }
}
function parseCookies(req: Request): Record<string,string> {
  return Object.fromEntries(String(req.headers.cookie || '').split(';').map(x => x.trim()).filter(Boolean).map(x => { const i=x.indexOf('='); return [x.slice(0,i),decodeURIComponent(x.slice(i+1))]; }));
}
function currentUser(req: Request) {
  const token = parseCookies(req).vaseteh_session;
  if (!token) return null;
  return db.prepare(`SELECT u.id,u.name,u.username FROM user_sessions s JOIN users u ON u.id=s.user_id WHERE s.token=? AND s.expires_at>? AND u.status='فعال'`).get(token, Date.now()) as {id:number;name:string;username:string}|undefined || null;
}
function requireUser(req: Request, res: Response) {
  const user = currentUser(req);
  if (!user) { res.status(401).json({ error: 'برای ادامه وارد حساب شوید.' }); return null; }
  return user;
}
function requireAdmin(req: Request, res: Response) {
  const token = String(req.headers['x-admin-token'] || '');
  const admin = token ? db.prepare('SELECT username,role FROM admin_tokens WHERE token=? AND expires_at>?').get(token, Date.now()) as {username:string;role:string}|undefined : undefined;
  if (!admin) { res.status(401).json({ error: 'unauthorized' }); return null; }
  return admin;
}
function currentAdmin(req: Request) {
  const token = String(req.headers['x-admin-token'] || '');
  if (!token) return null;
  return db.prepare('SELECT username,role FROM admin_tokens WHERE token=? AND expires_at>?').get(token, Date.now()) as {username:string;role:string}|undefined || null;
}
function logAdmin(username: string, action: string, details = '') {
  db.prepare('INSERT INTO activity_log (admin_username,action,details) VALUES (?,?,?)').run(username, action, details);
}
function canManageBrokers(admin: { username:string; role:string }): boolean {
  return admin.role === 'owner';
}
const cooperationStatuses = new Set(['فعال','تعلیق‌شده','مسدودشده','عزل‌شده','محروم‌شده','حذف‌شده']);
const restrictedCooperationStatuses = new Set(['تعلیق‌شده','مسدودشده','عزل‌شده','محروم‌شده']);
const violationStatuses = new Set(['در حال بررسی','تأیید داخلی','ردشده','مختومه']);
const activityTypes = new Set(['واسطه‌گری','مدیریت اتحاد','پاسخگوی انجمن','پشتیبانی انجمن','مالک انجمن','مدیریت انجمن','ادمین ثبت تخلفات','ادمین معاملات','ادمین ناظر']);
const verificationStatuses = new Set(['تأییدشده','در حال بررسی','نیازمند بررسی مجدد','فاقد تأیید','تعلیق اعتبار']);
function faDate(value: string): string {
  return new Intl.DateTimeFormat('fa-IR', { dateStyle:'medium', timeStyle:'short', timeZone:'Asia/Tehran' }).format(new Date(value.replace(' ', 'T') + 'Z'));
}
function messagesFor(conversationId: number) {
  const rows = db.prepare('SELECT id,sender,body,attachment_url AS attachmentUrl,created_at AS createdAt FROM messages WHERE conversation_id=? ORDER BY id').all(conversationId) as Array<{id:number;sender:string;body:string;attachmentUrl:string|null;createdAt:string}>;
  return rows.map(r => ({ ...r, attachmentUrl:r.attachmentUrl || undefined, createdAt:faDate(r.createdAt) }));
}
function shapeConversation(row: any, admin = false) {
  return {
    id:row.id, ticketCode:row.ticketCode || `REQ-${new Date().getFullYear()}-${String(row.id).padStart(6, '0')}`,
    subject:row.subject, status:row.status, priority:row.priority || 'عادی', department:row.department || 'پشتیبانی',
    assignee:row.assignee || '', unreadUser:row.unreadUser, unreadAdmin:row.unreadAdmin,
    createdAt:row.createdAt ? faDate(row.createdAt) : undefined, updatedAt:row.updatedAt ? faDate(row.updatedAt) : undefined,
    ...(admin?{userName:row.userName,username:row.username}:{}), messages:messagesFor(row.id)
  };
}
function verificationCode(id: number): string {
  return `VRF-${new Date().getFullYear()}-${String(id).padStart(6, '0')}`;
}
function entityCode(prefix: string, id: number): string {
  return `${prefix}-${new Date().getFullYear()}-${String(id).padStart(6, '0')}`;
}

function employeePublic(row: any) {
  return {
    id: row.id, name: row.name, handle: row.handle,
    employeeCode: row.employeeCode, verificationCode: row.verificationCode,
    department: row.department, positionTitle: row.positionTitle,
    status: row.status, publicStatusReason: row.publicStatusReason || '',
    startedAt: row.startedAt || '', updatedAt: faDate(row.updatedAt || row.createdAt)
  };
}
function safeUploadName(original: string, mime: string) {
  const ext = ({'image/jpeg':'.jpg','image/png':'.png','image/webp':'.webp','image/gif':'.gif','video/mp4':'.mp4','video/webm':'.webm','video/quicktime':'.mov'} as Record<string,string>)[mime] || '';
  return `${crypto.randomBytes(18).toString('hex')}${ext}`;
}
const uploadDir = path.join(process.cwd(), 'server', 'data', 'uploads');
fs.mkdirSync(uploadDir, { recursive: true });
function publicViolations(brokerId: number) {
  const rows=db.prepare(`SELECT id,title,description,status,evidence_url AS evidenceUrl,public_note AS managerNote,created_at AS createdAt FROM broker_violations WHERE broker_id=? AND public_visible=1 ORDER BY id DESC`).all(brokerId) as any[];
  return rows.map(row=>({...row,evidenceUrl:row.evidenceUrl||'',managerNote:row.managerNote||'',createdAt:faDate(row.createdAt)}));
}
function publicPartner(row: any) {
  return {
    id:row.id,name:row.name,handle:row.handle,partnerCode:row.partnerCode,verificationCode:row.verificationCode,
    status:row.status,verificationLevel:row.verificationLevel,cooperationType:row.cooperationType,category:row.category,
    cooperationStatus:row.cooperationStatus || 'فعال',positionTitle:row.positionTitle || row.cooperationType,
    publicStatusReason:Boolean(row.publicStatusReason) ? (row.statusReason || '') : '',
    statusStartedAt:row.statusStartedAt?faDate(row.statusStartedAt):'',statusEndsAt:row.statusEndsAt?faDate(row.statusEndsAt):'',
    updatedAt:faDate(row.updatedAt),lastReview:faDate(row.lastReview || row.updatedAt),qrActive:Boolean(row.qrActive),violations:publicViolations(row.id)
  };
}

app.get('/api/brokers', (_req,res) => {
  try { const rows=db.prepare("SELECT id,name,handle,active FROM brokers WHERE active=1 AND cooperation_status='فعال' ORDER BY id").all() as any[]; res.json({brokers:rows.map(x=>({...x,active:Boolean(x.active)}))}); }
  catch(error){ console.error('GET /api/brokers failed',error);res.status(500).json({error:'دریافت فهرست واسطه‌ها ممکن نشد.'}); }
});
app.get('/api/notices', (_req,res) => {
  try { const rows=db.prepare('SELECT id,title,body,active FROM notices WHERE active=1 ORDER BY id DESC').all() as any[];res.json({notices:rows.map(x=>({...x,active:Boolean(x.active)}))}); }
  catch(error){console.error('GET /api/notices failed',error);res.status(500).json({error:'دریافت اطلاعیه‌ها ممکن نشد.'})}
});
app.get('/api/verification/directory', (_req,res) => {
  try { const rows=db.prepare(`SELECT id,name,handle,partner_code AS partnerCode,verification_code AS verificationCode,verification_status AS status,verification_level AS verificationLevel,cooperation_type AS cooperationType,category,cooperation_status AS cooperationStatus,position_title AS positionTitle,status_reason AS statusReason,public_status_reason AS publicStatusReason,updated_at AS updatedAt,last_review AS lastReview,qr_active AS qrActive FROM brokers WHERE public_visible=1 AND active=1 AND cooperation_status='فعال' AND deleted_at IS NULL ORDER BY id DESC`).all() as any[];res.json({partners:rows.map(publicPartner)}); }
  catch(error){console.error('GET verification directory failed',error);res.status(500).json({error:'دریافت فهرست همکاران ممکن نشد.'})}
});
app.get('/api/verification/profile/:code', (req,res) => {
  try { const code=cleanText(req.params.code,100);const row=db.prepare(`SELECT id,name,handle,partner_code AS partnerCode,verification_code AS verificationCode,verification_status AS status,verification_level AS verificationLevel,cooperation_type AS cooperationType,category,cooperation_status AS cooperationStatus,position_title AS positionTitle,status_reason AS statusReason,public_status_reason AS publicStatusReason,status_started_at AS statusStartedAt,status_ends_at AS statusEndsAt,updated_at AS updatedAt,last_review AS lastReview,qr_active AS qrActive FROM brokers WHERE public_visible=1 AND deleted_at IS NULL AND (partner_code=? COLLATE NOCASE OR verification_code=? COLLATE NOCASE)`).get(code,code) as any;if(!row)return res.status(404).json({error:'پروفایل قابل انتشار پیدا نشد.'});res.json({profile:publicPartner(row)}); }
  catch(error){console.error('GET verification profile failed',error);res.status(500).json({error:'دریافت پروفایل ممکن نشد.'})}
});
app.post('/api/verification/applications', (req,res) => {
  try { const name=cleanText(req.body?.name,80),handle=cleanText(req.body?.handle,80),cooperationType=cleanText(req.body?.cooperationType,60),department=cleanText(req.body?.department,60),experience=cleanText(req.body?.experience,1000),description=cleanText(req.body?.description,2000);if(name.length<3||!/^@[A-Za-z0-9_]+$/.test(handle)||!cooperationType||!department||experience.length<10)return res.status(400).json({error:'اطلاعات درخواست کامل یا معتبر نیست.'});const duplicate=db.prepare("SELECT application_code AS code FROM partner_applications WHERE handle=? COLLATE NOCASE AND status NOT IN ('رد شد','بسته شد')").get(handle) as {code:string}|undefined;if(duplicate)return res.status(409).json({error:`برای این شناسه درخواست باز ${duplicate.code} وجود دارد.`});const result=db.prepare('INSERT INTO partner_applications (name,handle,cooperation_type,department,experience,description) VALUES (?,?,?,?,?,?)').run(name,handle,cooperationType,department,experience,description);const code=entityCode('COL',Number(result.lastInsertRowid));db.prepare('UPDATE partner_applications SET application_code=? WHERE id=?').run(code,result.lastInsertRowid);db.prepare('INSERT INTO admin_notifications (title,body,target) VALUES (?,?,?)').run('درخواست همکاری جدید',`${name} · ${handle}`,'partners');res.status(201).json({applicationCode:code,status:'دریافت شد'}); }
  catch(error){console.error('POST partner application failed',error);res.status(500).json({error:'ثبت درخواست همکاری ممکن نشد.'})}
});
app.get('/api/verification/applications/:code', (req,res) => {
  try { const code=cleanText(req.params.code,80);const row=db.prepare('SELECT application_code AS applicationCode,name,handle,cooperation_type AS cooperationType,department,status,created_at AS createdAt,updated_at AS updatedAt FROM partner_applications WHERE application_code=? COLLATE NOCASE').get(code) as any;if(!row)return res.status(404).json({error:'درخواستی با این کد پیدا نشد.'});res.json({application:{...row,createdAt:faDate(row.createdAt),updatedAt:faDate(row.updatedAt)}}); }
  catch(error){console.error('GET partner application failed',error);res.status(500).json({error:'پیگیری درخواست ممکن نشد.'})}
});
app.post('/api/verification/reverification', (req,res) => {
  try { const code=cleanText(req.body?.code,80),description=cleanText(req.body?.description,1000);const broker=db.prepare('SELECT id FROM brokers WHERE verification_code=? OR partner_code=?').get(code,code) as {id:number}|undefined;if(!broker)return res.status(404).json({error:'پروفایل موردنظر پیدا نشد.'});const ref=entityCode('REV',Number(`${Date.now()}`.slice(-6)));db.prepare('INSERT INTO admin_notifications (title,body,target) VALUES (?,?,?)').run('درخواست بررسی مجدد',`${ref} · ${code} · ${description}`,'verification');res.status(201).json({requestCode:ref}); }
  catch(error){console.error('POST reverification failed',error);res.status(500).json({error:'ثبت درخواست بررسی مجدد ممکن نشد.'})}
});
app.get('/api/employee-verification/directory', (_req,res) => {
  try {
    const rows=db.prepare(`SELECT id,name,handle,employee_code AS employeeCode,verification_code AS verificationCode,department,position_title AS positionTitle,status,public_status_reason AS publicStatusReason,started_at AS startedAt,updated_at AS updatedAt,created_at AS createdAt FROM employees WHERE public_visible=1 ORDER BY id DESC`).all() as any[];
    res.json({employees:rows.map(employeePublic)});
  } catch(error){console.error('GET employee directory failed',error);res.status(500).json({error:'دریافت فهرست کارمندان ممکن نشد.'})}
});
app.get('/api/employee-verification/:query', (req,res) => {
  try {
    const query=cleanText(req.params.query,100);
    const normalized=query.startsWith('@')?query:`@${query}`;
    const row=db.prepare(`SELECT id,name,handle,employee_code AS employeeCode,verification_code AS verificationCode,department,position_title AS positionTitle,status,public_status_reason AS publicStatusReason,started_at AS startedAt,updated_at AS updatedAt,created_at AS createdAt FROM employees WHERE public_visible=1 AND (handle=? COLLATE NOCASE OR employee_code=? COLLATE NOCASE OR verification_code=? COLLATE NOCASE)`).get(normalized,query,query) as any;
    if(!row)return res.json({found:false,message:'این شناسه یا کد کارمند در فهرست عمومی سامانه یافت نشد.'});
    res.json({found:true,result:{...employeePublic(row),checkedAt:new Intl.DateTimeFormat('fa-IR',{dateStyle:'medium',timeStyle:'short',timeZone:'Asia/Tehran'}).format(new Date())}});
  } catch(error){console.error('GET employee verification failed',error);res.status(500).json({error:'استعلام کارمند در حال حاضر ممکن نیست.'})}
});
app.get('/api/verification/:query', (req,res) => {
  try {
    const query=cleanText(req.params.query,100); const normalized=query.startsWith('@')?query:`@${query}`;
    const row=db.prepare(`SELECT id,name,handle,partner_code AS partnerCode,verification_code AS verificationCode,verification_status AS status,verification_level AS verificationLevel,cooperation_type AS cooperationType,category,cooperation_status AS cooperationStatus,position_title AS positionTitle,status_reason AS statusReason,public_status_reason AS publicStatusReason,status_started_at AS statusStartedAt,status_ends_at AS statusEndsAt,updated_at AS updatedAt,last_review AS lastReview,qr_active AS qrActive FROM brokers WHERE public_visible=1 AND deleted_at IS NULL AND (handle=? COLLATE NOCASE OR verification_code=? COLLATE NOCASE OR partner_code=? COLLATE NOCASE)`).get(normalized,query,query) as any;
    if(!row) { const similar=db.prepare("SELECT handle FROM brokers WHERE public_visible=1 AND deleted_at IS NULL AND REPLACE(LOWER(handle),'_','') LIKE ? LIMIT 1").get(`%${normalized.toLowerCase().replaceAll('_','').slice(0,8)}%`) as {handle:string}|undefined;return res.json({found:false,message:'این شناسه یا کد در فهرست قابل انتشار سامانه یافت نشد.',similarHandle:similar?.handle}); }
    res.json({found:true,result:{...publicPartner(row),checkedAt:new Intl.DateTimeFormat('fa-IR',{dateStyle:'medium',timeStyle:'short',timeZone:'Asia/Tehran'}).format(new Date())}});
  } catch(error){console.error('GET verification failed',{query:req.params.query,error});res.status(500).json({error:'استعلام در حال حاضر ممکن نیست.'})}
});
app.post('/api/verification/discrepancies',(req,res)=>{
  try{const handle=cleanText(req.body?.handle,80),reportType=cleanText(req.body?.reportType,80),description=cleanText(req.body?.description,2000);if(!handle||!reportType||description.length<10)return res.status(400).json({error:'اطلاعات گزارش مغایرت کامل نیست.'});db.prepare('INSERT INTO discrepancy_reports (handle,report_type,description) VALUES (?,?,?)').run(handle,reportType,description);res.status(201).json({ok:true})}catch(error){console.error('POST discrepancy failed',error);res.status(500).json({error:'ثبت گزارش مغایرت ممکن نشد.'})}
});

app.post('/api/auth/register', (req,res) => {
  try {
    const name=cleanText(req.body?.name,80), username=normalizeUsername(req.body?.username), password=String(req.body?.password||'');
    if(name.length<3||username.length<3||password.length<8) return res.status(400).json({error:'اطلاعات عضویت کامل یا معتبر نیست.'});
    const result=db.prepare('INSERT INTO users (name,username,password_hash) VALUES (?,?,?)').run(name,username,passwordHash(password));
    const token=crypto.randomBytes(32).toString('base64url'); db.prepare('INSERT INTO user_sessions (token,user_id,expires_at) VALUES (?,?,?)').run(token,result.lastInsertRowid,Date.now()+SESSION_AGE);
    res.setHeader('Set-Cookie',`vaseteh_session=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${SESSION_AGE/1000}`);res.status(201).json({user:{id:Number(result.lastInsertRowid),name,username,unread:0}});
  } catch(error:any){console.error('POST /api/auth/register failed',{username:req.body?.username,error});res.status(error?.code==='ERR_SQLITE_CONSTRAINT_UNIQUE'?409:500).json({error:error?.code==='ERR_SQLITE_CONSTRAINT_UNIQUE'?'این نام کاربری قبلاً ثبت شده است.':'ساخت حساب ممکن نشد.'});}
});
app.post('/api/auth/login',(req,res)=>{
  try{const username=normalizeUsername(req.body?.username),password=String(req.body?.password||'');const user=db.prepare('SELECT id,name,username,status,password_hash AS passwordHash FROM users WHERE username=?').get(username) as any;if(!user||!verifyPassword(password,user.passwordHash))return res.status(401).json({error:'نام کاربری یا رمز عبور نادرست است.'});if(user.status!=='فعال')return res.status(403).json({error:'این حساب در حال حاضر غیرفعال است.'});const token=crypto.randomBytes(32).toString('base64url');db.prepare('INSERT INTO user_sessions (token,user_id,expires_at) VALUES (?,?,?)').run(token,user.id,Date.now()+SESSION_AGE);res.setHeader('Set-Cookie',`vaseteh_session=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${SESSION_AGE/1000}`);const unread=(db.prepare('SELECT COALESCE(SUM(unread_user),0) AS c FROM conversations WHERE user_id=?').get(user.id) as any).c;res.json({user:{id:user.id,name:user.name,username:user.username,unread}})}catch(error){console.error('POST /api/auth/login failed',error);res.status(500).json({error:'ورود به حساب ممکن نشد.'})}
});
app.get('/api/auth/me',(req,res)=>{try{const user=currentUser(req);if(!user)return res.json({user:null});const unread=(db.prepare('SELECT COALESCE(SUM(unread_user),0) AS c FROM conversations WHERE user_id=?').get(user.id) as any).c;res.json({user:{...user,unread}})}catch(error){console.error('GET /api/auth/me failed',error);res.status(500).json({error:'بررسی حساب ممکن نشد.'})}});
app.post('/api/auth/logout',(req,res)=>{const token=parseCookies(req).vaseteh_session;if(token)db.prepare('DELETE FROM user_sessions WHERE token=?').run(token);res.setHeader('Set-Cookie','vaseteh_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0');res.json({ok:true})});

app.get('/api/conversations',(req,res)=>{try{const user=requireUser(req,res);if(!user)return;const rows=db.prepare('SELECT id,subject,status,unread_user AS unreadUser,unread_admin AS unreadAdmin FROM conversations WHERE user_id=? ORDER BY updated_at DESC').all(user.id) as any[];db.prepare('UPDATE conversations SET unread_user=0 WHERE user_id=?').run(user.id);res.json({conversations:rows.map(r=>shapeConversation(r))})}catch(error){console.error('GET /api/conversations failed',error);res.status(500).json({error:'دریافت پیام‌ها ممکن نشد.'})}});
app.post('/api/conversations',(req,res)=>{try{const user=requireUser(req,res);if(!user)return;const subject=cleanText(req.body?.subject,60),body=cleanText(req.body?.body),attachmentUrl=cleanText(req.body?.attachmentUrl,300);if(!categories.has(subject)||(!body&& !attachmentUrl))return res.status(400).json({error:'موضوع یا متن پیام معتبر نیست.'});if(attachmentUrl&&!attachmentUrl.startsWith('/api/uploads/'))return res.status(400).json({error:'پیوست معتبر نیست.'});const result=db.prepare("INSERT INTO conversations (user_id,subject,status) VALUES (?,?,'جدید')").run(user.id,subject);db.prepare("INSERT INTO messages (conversation_id,sender,body,attachment_url) VALUES (?,'user',?,?)").run(result.lastInsertRowid,body||'📎 پیوست',attachmentUrl||null);const row=db.prepare('SELECT id,subject,status,unread_user AS unreadUser,unread_admin AS unreadAdmin FROM conversations WHERE id=?').get(result.lastInsertRowid);res.status(201).json({conversation:shapeConversation(row)})}catch(error){console.error('POST /api/conversations failed',{user:currentUser(req)?.id,error});res.status(500).json({error:'ارسال پیام ممکن نشد.'})}});
app.post('/api/conversations/:id/messages',(req,res)=>{try{const user=requireUser(req,res);if(!user)return;const id=Number(req.params.id),body=cleanText(req.body?.body),attachmentUrl=cleanText(req.body?.attachmentUrl,300);const conversation=db.prepare('SELECT status FROM conversations WHERE id=? AND user_id=?').get(id,user.id) as any;if(!conversation)return res.status(404).json({error:'گفتگو پیدا نشد.'});if(conversation.status==='بسته شد')return res.status(409).json({error:'این گفتگو بسته شده است.'});if(!body&&!attachmentUrl)return res.status(400).json({error:'متن یا فایل پیام را وارد کنید.'});if(attachmentUrl&&!attachmentUrl.startsWith('/api/uploads/'))return res.status(400).json({error:'پیوست معتبر نیست.'});const result=db.prepare("INSERT INTO messages (conversation_id,sender,body,attachment_url) VALUES (?,'user',?,?)").run(id,body||'📎 پیوست',attachmentUrl||null);db.prepare("UPDATE conversations SET status='در انتظار پاسخ کاربر',unread_admin=unread_admin+1,updated_at=CURRENT_TIMESTAMP WHERE id=?").run(id);const row=db.prepare('SELECT id,sender,body,attachment_url AS attachmentUrl,created_at AS createdAt FROM messages WHERE id=?').get(result.lastInsertRowid) as any;res.status(201).json({message:{...row,attachmentUrl:row.attachmentUrl||undefined,createdAt:faDate(row.createdAt)}})}catch(error){console.error('POST user message failed',{id:req.params.id,error});res.status(500).json({error:'ارسال پاسخ ممکن نشد.'})}});

app.post('/api/uploads', (req,res) => {
  try {
    const user = currentUser(req);
    const admin = currentAdmin(req);
    if (!user && !admin) return res.status(401).json({error:'برای ارسال فایل وارد حساب شوید.'});
    const mime = cleanText(req.body?.mimeType,80).toLowerCase();
    const data = String(req.body?.data || '');
    const originalName = cleanText(req.body?.fileName,160);
    const allowed = new Set(['image/jpeg','image/png','image/webp','image/gif','video/mp4','video/webm','video/quicktime']);
    if (!allowed.has(mime)) return res.status(400).json({error:'فقط تصویر و ویدئوی مجاز قابل ارسال است.'});
    const raw = data.replace(/^data:[^;]+;base64,/, '');
    if (!raw || raw.length > 20_000_000) return res.status(413).json({error:'حجم فایل بیش از حد مجاز است.'});
    const buffer = Buffer.from(raw,'base64');
    if (buffer.length > 15 * 1024 * 1024) return res.status(413).json({error:'حداکثر حجم فایل ۱۵ مگابایت است.'});
    const filename = safeUploadName(originalName,mime);
    fs.writeFileSync(path.join(uploadDir,filename),buffer,{flag:'wx'});
    db.prepare('INSERT INTO uploaded_files (filename,original_name,mime_type,size,user_id,admin_username) VALUES (?,?,?,?,?,?)').run(filename,originalName,mime,buffer.length,user?.id||null,admin?.username||null);
    res.status(201).json({url:`/api/uploads/${filename}`,fileName:originalName,mimeType:mime,size:buffer.length});
  } catch(error){console.error('POST upload failed',error);res.status(500).json({error:'آپلود فایل ممکن نشد.'})}
});
app.get('/api/uploads/:name', (req,res) => {
  try {
    const user = currentUser(req);
    const admin = currentAdmin(req);
    if (!user && !admin) return res.status(401).json({error:'دسترسی به فایل نیازمند ورود است.'});
    const name = path.basename(req.params.name);
    const record=db.prepare('SELECT user_id AS userId,admin_username AS adminUsername,mime_type AS mimeType FROM uploaded_files WHERE filename=?').get(name) as any;
    if (!record) return res.status(404).end();
    if (!admin && (!user || record.userId !== user.id)) return res.status(403).json({error:'دسترسی به این فایل مجاز نیست.'});
    const file = path.join(uploadDir,name);
    if (!fs.existsSync(file)) return res.status(404).end();
    const ext=path.extname(name).toLowerCase();
    const types:Record<string,string>={'.jpg':'image/jpeg','.jpeg':'image/jpeg','.png':'image/png','.webp':'image/webp','.gif':'image/gif','.mp4':'video/mp4','.webm':'video/webm','.mov':'video/quicktime'};
    res.setHeader('Content-Type',types[ext]||'application/octet-stream');
    res.setHeader('Cache-Control','private, max-age=3600');
    fs.createReadStream(file).pipe(res);
  } catch(error){res.status(500).json({error:'دریافت فایل ممکن نشد.'})}
});

app.post('/api/admin/login',(req,res)=>{
  try{
    const username=String(req.body?.username||'').trim(),password=String(req.body?.password||'');
    const recent=(db.prepare("SELECT COUNT(*) AS c FROM admin_login_attempts WHERE username=? AND success=0 AND created_at>datetime('now','-15 minutes')").get(username) as {c:number}).c;
    if(recent>=5)return res.status(429).json({error:'تعداد تلاش‌های ناموفق زیاد است؛ ۱۵ دقیقه دیگر دوباره تلاش کنید.'});
    const userOk=username===ADMIN_USERNAME,passA=Buffer.from(password),passB=Buffer.from(ADMIN_PASSWORD);const passOk=passA.length===passB.length&&crypto.timingSafeEqual(passA,passB);
    db.prepare('INSERT INTO admin_login_attempts (username,success) VALUES (?,?)').run(username,userOk&&passOk?1:0);
    if(!userOk||!passOk)return res.status(401).json({error:'اطلاعات ورود مدیریت نادرست است.'});
    if(req.body?.endOtherSessions)db.prepare('DELETE FROM admin_tokens WHERE username=?').run(username);
    const token=crypto.randomBytes(40).toString('base64url');db.prepare('INSERT INTO admin_tokens (token,username,role,expires_at) VALUES (?,?,?,?)').run(token,username,'owner',Date.now()+SESSION_AGE);logAdmin(username,'ورود به پنل');
    res.json({token,profile:{username,role:'مدیر کل',displayName:'مدیر مجموعه',permissions:['view','create','edit','delete','reply','assign','export','manage']}});
  }catch(error){console.error('POST admin login failed',error);res.status(500).json({error:'ورود مدیریت ممکن نشد.'})}
});
app.get('/api/admin/me',(req,res)=>{const admin=requireAdmin(req,res);if(!admin)return;res.json({profile:{username:admin.username,role:'مدیر کل',displayName:'مدیر مجموعه',permissions:['view','create','edit','delete','reply','assign','export','manage']}})});
app.post('/api/admin/logout',(req,res)=>{const token=String(req.headers['x-admin-token']||'');const admin=requireAdmin(req,res);if(!admin)return;db.prepare('DELETE FROM admin_tokens WHERE token=?').run(token);logAdmin(admin.username,'خروج از پنل');res.json({ok:true})});
app.get('/api/admin/dashboard',(req,res)=>{try{if(!requireAdmin(req,res))return;const one=(sql:string)=>(db.prepare(sql).get() as {c:number}).c;const stats={unreadMessages:one('SELECT COALESCE(SUM(unread_admin),0) AS c FROM conversations'),openTickets:one("SELECT COUNT(*) AS c FROM conversations WHERE status<>'بسته شد'"),urgentTickets:one("SELECT COUNT(*) AS c FROM conversations WHERE priority='فوری' AND status<>'بسته شد'"),newReports:one("SELECT COUNT(*) AS c FROM conversations WHERE subject='گزارش تخلف' AND status='جدید'"),activeUsers:one("SELECT COUNT(*) AS c FROM users WHERE status='فعال'"),activeBrokers:one("SELECT COUNT(*) AS c FROM brokers WHERE active=1 AND cooperation_status='فعال'"),suspendedBrokers:one("SELECT COUNT(*) AS c FROM brokers WHERE cooperation_status='تعلیق‌شده'"),blockedBrokers:one("SELECT COUNT(*) AS c FROM brokers WHERE cooperation_status='مسدودشده'"),dismissedBrokers:one("SELECT COUNT(*) AS c FROM brokers WHERE cooperation_status='عزل‌شده'"),bannedBrokers:one("SELECT COUNT(*) AS c FROM brokers WHERE cooperation_status='محروم‌شده'"),partnerApplications:one("SELECT COUNT(*) AS c FROM partner_applications WHERE status NOT IN ('رد شد','تأیید و منتشر شد','بسته شد')"),mismatchReports:one("SELECT COUNT(*) AS c FROM discrepancy_reports WHERE status='دریافت شد'"),pendingVerification:one("SELECT COUNT(*) AS c FROM brokers WHERE verification_status='نیازمند بروزرسانی'")};const trend=Array.from({length:7},(_,i)=>({day:new Intl.DateTimeFormat('fa-IR',{weekday:'short'}).format(new Date(Date.now()-(6-i)*86400000)),tickets:Math.max(0,Math.round(stats.openTickets/7)+(i%3)),messages:Math.max(0,Math.round(stats.unreadMessages/7)+((i+1)%3))}));const alerts=[{type:'unanswered',count:stats.unreadMessages,label:'پیام بدون پاسخ',target:'messages'},{type:'urgent',count:stats.urgentTickets,label:'درخواست فوری',target:'tickets'},{type:'reports',count:stats.newReports,label:'پرونده نیازمند بررسی',target:'tickets'},{type:'security',count:one("SELECT COUNT(*) AS c FROM admin_login_attempts WHERE success=0 AND created_at>datetime('now','-1 day')"),label:'ورود ناموفق',target:'security'}].filter(x=>x.count>0);res.json({stats,alerts,trend})}catch(error){console.error('GET admin dashboard failed',error);res.status(500).json({error:'دریافت داشبورد ممکن نشد.'})}});
app.get('/api/admin/conversations',(req,res)=>{try{const admin=requireAdmin(req,res);if(!admin)return;const search=cleanText(req.query.search,100),status=cleanText(req.query.status,40);const like=`%${search}%`;const rows=db.prepare(`SELECT c.id,c.ticket_code AS ticketCode,c.subject,c.status,c.priority,c.department,c.assignee,c.created_at AS createdAt,c.updated_at AS updatedAt,c.unread_user AS unreadUser,c.unread_admin AS unreadAdmin,u.name AS userName,u.username FROM conversations c JOIN users u ON u.id=c.user_id WHERE (?='' OR u.name LIKE ? OR u.username LIKE ? OR c.subject LIKE ? OR EXISTS(SELECT 1 FROM messages m WHERE m.conversation_id=c.id AND m.body LIKE ?)) AND (?='همه' OR c.status=?) ORDER BY c.updated_at DESC`).all(search,like,like,like,like,status,status) as any[];res.json({conversations:rows.map(r=>shapeConversation(r,true))})}catch(error){console.error('GET admin conversations failed',error);res.status(500).json({error:'دریافت پیام‌ها ممکن نشد.'})}});
app.patch('/api/admin/conversations/:id',(req,res)=>{try{const admin=requireAdmin(req,res);if(!admin)return;const id=Number(req.params.id),status=cleanText(req.body?.status,40),priority=cleanText(req.body?.priority,30),assignee=cleanText(req.body?.assignee,80);if(status&&!statuses.has(status))return res.status(400).json({error:'وضعیت معتبر نیست.'});if(priority&&!['عادی','متوسط','مهم','فوری'].includes(priority))return res.status(400).json({error:'اولویت معتبر نیست.'});if(status)db.prepare('UPDATE conversations SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(status,id);if(priority)db.prepare('UPDATE conversations SET priority=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(priority,id);if(assignee)db.prepare('UPDATE conversations SET assignee=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(assignee,id);logAdmin(admin.username,'بروزرسانی تیکت',String(id));res.json({ok:true})}catch(error){console.error('PATCH ticket failed',error);res.status(500).json({error:'بروزرسانی تیکت ممکن نشد.'})}});
app.post('/api/admin/conversations/:id/notes',(req,res)=>{try{const admin=requireAdmin(req,res);if(!admin)return;const body=cleanText(req.body?.body,2000);if(!body)return res.status(400).json({error:'یادداشت خالی است.'});db.prepare('INSERT INTO internal_notes (conversation_id,admin_username,body) VALUES (?,?,?)').run(Number(req.params.id),admin.username,body);logAdmin(admin.username,'ثبت یادداشت داخلی',req.params.id);res.status(201).json({ok:true})}catch(error){console.error('POST internal note failed',error);res.status(500).json({error:'ثبت یادداشت ممکن نشد.'})}});
app.post('/api/admin/conversations/:id/messages',(req,res)=>{try{const admin=requireAdmin(req,res);if(!admin)return;const id=Number(req.params.id),body=cleanText(req.body?.body),attachmentUrl=cleanText(req.body?.attachmentUrl,300);if(!body&&!attachmentUrl)return res.status(400).json({error:'متن یا فایل پاسخ را وارد کنید.'});if(attachmentUrl&&!attachmentUrl.startsWith('/api/uploads/'))return res.status(400).json({error:'پیوست معتبر نیست.'});const exists=db.prepare('SELECT id FROM conversations WHERE id=?').get(id);if(!exists)return res.status(404).json({error:'گفتگو پیدا نشد.'});db.prepare("INSERT INTO messages (conversation_id,sender,body,attachment_url) VALUES (?,'admin',?,?)").run(id,body||'📎 پیوست',attachmentUrl||null);db.prepare("UPDATE conversations SET status='پاسخ داده شد',unread_user=unread_user+1,unread_admin=0,updated_at=CURRENT_TIMESTAMP WHERE id=?").run(id);logAdmin(admin.username,'پاسخ به پیام',String(id));res.status(201).json({ok:true})}catch(error){console.error('POST admin message failed',{id:req.params.id,error});res.status(500).json({error:'ثبت پاسخ ممکن نشد.'})}});
app.patch('/api/admin/conversations/:id/status',(req,res)=>{try{const admin=requireAdmin(req,res);if(!admin)return;const status=cleanText(req.body?.status,40);if(!statuses.has(status))return res.status(400).json({error:'وضعیت معتبر نیست.'});db.prepare('UPDATE conversations SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(status,Number(req.params.id));logAdmin(admin.username,'تغییر وضعیت گفتگو',`${req.params.id}: ${status}`);res.json({ok:true})}catch(error){console.error('PATCH conversation status failed',error);res.status(500).json({error:'تغییر وضعیت ممکن نشد.'})}});
app.get('/api/admin/users',(req,res)=>{try{if(!requireAdmin(req,res))return;const rows=db.prepare(`SELECT u.id,u.name,u.username,u.status,u.created_at AS createdAt,COALESCE(u.last_activity,u.created_at) AS lastActivity,COUNT(DISTINCT c.id) AS tickets,COUNT(m.id) AS messages FROM users u LEFT JOIN conversations c ON c.user_id=u.id LEFT JOIN messages m ON m.conversation_id=c.id GROUP BY u.id ORDER BY u.id DESC`).all() as any[];res.json({users:rows.map(x=>({...x,createdAt:faDate(x.createdAt),lastActivity:faDate(x.lastActivity)}))})}catch(error){console.error('GET admin users failed',error);res.status(500).json({error:'دریافت کاربران ممکن نشد.'})}});
app.patch('/api/admin/users/:id',(req,res)=>{try{const admin=requireAdmin(req,res);if(!admin)return;const id=Number(req.params.id),status=cleanText(req.body?.status,20);if(!['فعال','تعلیق‌شده'].includes(status))return res.status(400).json({error:'وضعیت کاربر معتبر نیست.'});const result=db.prepare('UPDATE users SET status=? WHERE id=?').run(status,id);if(result.changes===0)return res.status(404).json({error:'کاربر پیدا نشد.'});db.prepare('DELETE FROM user_sessions WHERE user_id=?').run(id);logAdmin(admin.username,'تغییر وضعیت کاربر',`${id}: ${status}`);res.json({ok:true})}catch(error){console.error('PATCH admin user failed',{id:req.params.id,error});res.status(500).json({error:'تغییر وضعیت کاربر ممکن نشد.'})}});
app.get('/api/admin/logs',(req,res)=>{try{if(!requireAdmin(req,res))return;const rows=db.prepare('SELECT id,admin_username AS adminUsername,action,details,created_at AS createdAt FROM activity_log ORDER BY id DESC LIMIT 100').all() as any[];res.json({logs:rows.map(x=>({...x,createdAt:faDate(x.createdAt)}))})}catch(error){console.error('GET admin logs failed',error);res.status(500).json({error:'دریافت سوابق ممکن نشد.'})}});
app.get('/api/admin/security',(req,res)=>{try{if(!requireAdmin(req,res))return;const activeSessions=(db.prepare('SELECT COUNT(*) AS c FROM admin_tokens WHERE expires_at>?').get(Date.now()) as any).c;const failedAttempts=(db.prepare("SELECT COUNT(*) AS c FROM admin_login_attempts WHERE success=0 AND created_at>datetime('now','-1 day')").get() as any).c;const rows=db.prepare('SELECT username,success,created_at AS createdAt FROM admin_login_attempts ORDER BY id DESC LIMIT 20').all() as any[];res.json({activeSessions,failedAttempts,recentLogins:rows.map(x=>({...x,success:Boolean(x.success),createdAt:faDate(x.createdAt)}))})}catch(error){console.error('GET admin security failed',error);res.status(500).json({error:'دریافت رویدادهای امنیتی ممکن نشد.'})}});
app.get('/api/admin/notifications',(req,res)=>{try{if(!requireAdmin(req,res))return;const rows=db.prepare('SELECT id,title,body,target,is_read AS isRead,created_at AS createdAt FROM admin_notifications ORDER BY id DESC LIMIT 100').all() as any[];res.json({notifications:rows.map(x=>({...x,isRead:Boolean(x.isRead),createdAt:faDate(x.createdAt)}))})}catch(error){console.error('GET admin notifications failed',error);res.status(500).json({error:'دریافت اعلان‌ها ممکن نشد.'})}});
app.patch('/api/admin/notifications/:id/read',(req,res)=>{try{const admin=requireAdmin(req,res);if(!admin)return;db.prepare('UPDATE admin_notifications SET is_read=1 WHERE id=?').run(Number(req.params.id));logAdmin(admin.username,'مشاهده اعلان',req.params.id);res.json({ok:true})}catch(error){console.error('PATCH admin notification failed',error);res.status(500).json({error:'بروزرسانی اعلان ممکن نشد.'})}});
app.get('/api/admin/partners',(req,res)=>{try{if(!requireAdmin(req,res))return;const rows=db.prepare('SELECT id,application_code AS applicationCode,name,handle,cooperation_type AS cooperationType,department,status,priority,assignee,internal_note AS internalNote,created_at AS createdAt,updated_at AS updatedAt FROM partner_applications ORDER BY id DESC').all() as any[];res.json({applications:rows.map(x=>({...x,createdAt:faDate(x.createdAt),updatedAt:faDate(x.updatedAt)}))})}catch(error){console.error('GET admin partners failed',error);res.status(500).json({error:'دریافت درخواست‌های همکاری ممکن نشد.'})}});
app.patch('/api/admin/partners/:id',(req,res)=>{try{const admin=requireAdmin(req,res);if(!admin)return;const id=Number(req.params.id),status=cleanText(req.body?.status,50),priority=cleanText(req.body?.priority,30),assignee=cleanText(req.body?.assignee,80),internalNote=cleanText(req.body?.internalNote,1500);const allowed=['دریافت شد','بررسی اولیه','نیازمند اطلاعات','در حال بررسی','تأیید و منتشر شد','رد شد','تعلیق'];if(status&&!allowed.includes(status))return res.status(400).json({error:'وضعیت معتبر نیست.'});const old=db.prepare('SELECT * FROM partner_applications WHERE id=?').get(id) as any;if(!old)return res.status(404).json({error:'درخواست پیدا نشد.'});db.prepare('UPDATE partner_applications SET status=?,priority=?,assignee=?,internal_note=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(status||old.status,priority||old.priority,assignee||old.assignee,internalNote||old.internal_note,id);if(status==='تأیید و منتشر شد'){const existing=db.prepare('SELECT id FROM brokers WHERE handle=? COLLATE NOCASE').get(old.handle) as {id:number}|undefined;if(!existing){const made=db.prepare('INSERT INTO brokers (name,handle,cooperation_type,category) VALUES (?,?,?,?)').run(old.name,old.handle,old.cooperation_type,old.department);const brokerId=Number(made.lastInsertRowid);db.prepare('UPDATE brokers SET verification_code=?,partner_code=?,last_review=CURRENT_TIMESTAMP,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(entityCode('VRF',brokerId),entityCode('PART',brokerId),brokerId);}}logAdmin(admin.username,'بروزرسانی درخواست همکاری',`${old.application_code}: ${old.status} → ${status||old.status}`);res.json({ok:true})}catch(error){console.error('PATCH admin partner failed',error);res.status(500).json({error:'بروزرسانی درخواست ممکن نشد.'})}});
app.get('/api/admin/mismatches',(req,res)=>{try{if(!requireAdmin(req,res))return;const rows=db.prepare('SELECT id,handle,report_type AS reportType,description,status,created_at AS createdAt FROM discrepancy_reports ORDER BY id DESC').all() as any[];res.json({reports:rows.map(x=>({...x,createdAt:faDate(x.createdAt)}))})}catch(error){console.error('GET mismatches failed',error);res.status(500).json({error:'دریافت مغایرت‌ها ممکن نشد.'})}});
app.patch('/api/admin/mismatches/:id',(req,res)=>{try{const admin=requireAdmin(req,res);if(!admin)return;const status=cleanText(req.body?.status,30);if(!['دریافت شد','در حال بررسی','نیازمند اطلاعات','بررسی شد','بسته شد'].includes(status))return res.status(400).json({error:'وضعیت گزارش معتبر نیست.'});const result=db.prepare('UPDATE discrepancy_reports SET status=? WHERE id=?').run(status,Number(req.params.id));if(result.changes===0)return res.status(404).json({error:'گزارش پیدا نشد.'});logAdmin(admin.username,'تغییر وضعیت گزارش مغایرت',`${req.params.id}: ${status}`);res.json({ok:true})}catch(error){console.error('PATCH mismatch failed',{id:req.params.id,error});res.status(500).json({error:'تغییر وضعیت گزارش ممکن نشد.'})}});
app.get('/api/admin/health',(req,res)=>{if(!requireAdmin(req,res))return;res.json({services:[{name:'اطلاعات سامانه',status:'عملیاتی'},{name:'پیام‌رسانی',status:'عملیاتی'},{name:'اعلان‌ها',status:'عملیاتی'},{name:'فضای خصوصی مستندات',status:'غیرفعال'},{name:'ایمیل',status:'غیرفعال'}],checkedAt:new Intl.DateTimeFormat('fa-IR',{dateStyle:'medium',timeStyle:'short',timeZone:'Asia/Tehran'}).format(new Date())})});
app.get('/api/admin/brokers',(req,res)=>{try{const admin=requireAdmin(req,res);if(!admin)return;const rows=db.prepare(`SELECT id,name,handle,active,verification_code AS verificationCode,partner_code AS partnerCode,verification_status AS verificationStatus,verification_level AS verificationLevel,cooperation_type AS cooperationType,category,public_visible AS publicVisible,qr_active AS qrActive,activity_type AS activityType,position_title AS positionTitle,cooperation_status AS cooperationStatus,status_reason AS statusReason,status_notes AS statusNotes,status_started_at AS statusStartedAt,status_ends_at AS statusEndsAt,status_applied_by AS statusAppliedBy,public_status_reason AS publicStatusReason,verification_notes AS verificationNotes,verification_reviewed_by AS verificationReviewedBy,official_contact AS officialContact,deleted_at AS deletedAt,deleted_by AS deletedBy,deletion_reason AS deletionReason,created_at AS createdAt,updated_at AS updatedAt FROM brokers ORDER BY id DESC`).all() as any[];const brokers=rows.map(x=>({...x,active:Boolean(x.active),publicVisible:Boolean(x.publicVisible),qrActive:Boolean(x.qrActive),publicStatusReason:Boolean(x.publicStatusReason),createdAt:faDate(x.createdAt),updatedAt:x.updatedAt?faDate(x.updatedAt):faDate(x.createdAt)}));const summary={total:brokers.filter(x=>!x.deletedAt).length,active:brokers.filter(x=>x.cooperationStatus==='فعال'&&!x.deletedAt).length,suspended:brokers.filter(x=>x.cooperationStatus==='تعلیق‌شده'&&!x.deletedAt).length,blocked:brokers.filter(x=>x.cooperationStatus==='مسدودشده'&&!x.deletedAt).length,dismissed:brokers.filter(x=>x.cooperationStatus==='عزل‌شده'&&!x.deletedAt).length,banned:brokers.filter(x=>x.cooperationStatus==='محروم‌شده'&&!x.deletedAt).length,deleted:brokers.filter(x=>Boolean(x.deletedAt)).length};res.json({brokers,summary,canManage:canManageBrokers(admin)})}catch(error){console.error('GET admin brokers failed',error);res.status(500).json({error:'دریافت اطلاعات واسطه‌ها ممکن نشد.'})}});
app.post('/api/admin/brokers',(req,res)=>{try{const admin=requireAdmin(req,res);if(!admin)return;if(!canManageBrokers(admin))return res.status(403).json({error:'شما مجوز افزودن فرد را ندارید.'});const name=cleanText(req.body?.name,80),handle=cleanText(req.body?.handle,80),activityType=cleanText(req.body?.activityType,60),positionTitle=cleanText(req.body?.positionTitle,60),officialContact=cleanText(req.body?.officialContact,160);if(!name||!/^@[A-Za-z0-9_]+$/.test(handle)||!activityTypes.has(activityType))return res.status(400).json({error:'نام، شناسه یا نوع فعالیت معتبر نیست.'});const result=db.prepare('INSERT INTO brokers (name,handle,activity_type,position_title,cooperation_type,official_contact,status_started_at,status_applied_by) VALUES (?,?,?,?,?,?,CURRENT_TIMESTAMP,?)').run(name,handle,activityType,positionTitle||activityType,activityType,officialContact,admin.username);const brokerId=Number(result.lastInsertRowid),code=verificationCode(brokerId),partnerCode=entityCode('PART',brokerId);db.prepare('UPDATE brokers SET verification_code=?,partner_code=?,last_review=CURRENT_TIMESTAMP,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(code,partnerCode,brokerId);db.prepare('INSERT INTO verification_history (broker_id,previous_status,new_status,admin_username,reason,notes,starts_at) VALUES (?,?,?,?,?,?,CURRENT_TIMESTAMP)').run(brokerId,null,'فعال',admin.username,'ثبت اولیه فرد','ایجاد پروفایل مدیریتی');logAdmin(admin.username,'افزودن واسطه یا عضو',`${handle} · ${activityType} · ${code}`);res.status(201).json({ok:true,verificationCode:code,partnerCode})}catch(error:any){console.error('POST broker failed',error);res.status(error?.code==='ERR_SQLITE_CONSTRAINT_UNIQUE'?409:500).json({error:error?.code==='ERR_SQLITE_CONSTRAINT_UNIQUE'?'این شناسه قبلاً ثبت شده است.':'افزودن فرد ممکن نشد.'})}});
app.patch('/api/admin/brokers/:id',(req,res)=>{try{const admin=requireAdmin(req,res);if(!admin)return;if(!canManageBrokers(admin))return res.status(403).json({error:'شما مجوز ویرایش این بخش را ندارید.'});const id=Number(req.params.id),name=cleanText(req.body?.name,80),handle=cleanText(req.body?.handle,80),activityType=cleanText(req.body?.activityType,60),positionTitle=cleanText(req.body?.positionTitle,60),verificationStatus=cleanText(req.body?.verificationStatus,40),verificationLevel=Math.min(5,Math.max(1,Number(req.body?.verificationLevel)||1)),verificationNotes=cleanText(req.body?.verificationNotes,1000),officialContact=cleanText(req.body?.officialContact,160),publicVisible=req.body?.publicVisible?1:0;if(!name||!/^@[A-Za-z0-9_]+$/.test(handle)||!activityTypes.has(activityType)||!verificationStatuses.has(verificationStatus))return res.status(400).json({error:'اطلاعات فرد یا اعتبارسنجی معتبر نیست.'});const result=db.prepare('UPDATE brokers SET name=?,handle=?,activity_type=?,position_title=?,cooperation_type=?,verification_status=?,verification_level=?,verification_notes=?,verification_reviewed_by=?,official_contact=?,public_visible=?,updated_at=CURRENT_TIMESTAMP,last_review=CURRENT_TIMESTAMP WHERE id=?').run(name,handle,activityType,positionTitle||activityType,activityType,verificationStatus,verificationLevel,verificationNotes,admin.username,officialContact,publicVisible,id);if(result.changes===0)return res.status(404).json({error:'فرد موردنظر پیدا نشد.'});logAdmin(admin.username,'ویرایش اطلاعات و اعتبارسنجی',`${handle} · ${verificationStatus} · سطح ${verificationLevel}`);res.json({ok:true})}catch(error){console.error('PATCH broker failed',error);res.status(500).json({error:'ویرایش اطلاعات ممکن نشد.'})}});
app.get('/api/admin/brokers/:id/history',(req,res)=>{try{const admin=requireAdmin(req,res);if(!admin)return;if(!canManageBrokers(admin))return res.status(403).json({error:'شما مجوز مشاهده تاریخچه حساس را ندارید.'});const rows=db.prepare('SELECT id,previous_status AS previousStatus,new_status AS newStatus,reason,notes,starts_at AS startsAt,ends_at AS endsAt,duration_label AS durationLabel,admin_username AS adminUsername,created_at AS createdAt FROM verification_history WHERE broker_id=? ORDER BY id DESC').all(Number(req.params.id)) as any[];res.json({history:rows.map(x=>({...x,createdAt:faDate(x.createdAt),startsAt:x.startsAt?faDate(x.startsAt):'',endsAt:x.endsAt?faDate(x.endsAt):''}))})}catch(error){console.error('GET broker history failed',error);res.status(500).json({error:'دریافت تاریخچه وضعیت ممکن نشد.'})}});
app.post('/api/admin/brokers/:id/status',(req,res)=>{try{const admin=requireAdmin(req,res);if(!admin)return;if(!canManageBrokers(admin))return res.status(403).json({error:'شما مجوز تغییر وضعیت همکاری را ندارید.'});const id=Number(req.params.id),newStatus=cleanText(req.body?.status,40),reason=cleanText(req.body?.reason,500),notes=cleanText(req.body?.notes,1200),endsAt=cleanText(req.body?.endsAt,40),confirmation=cleanText(req.body?.confirmation,20),publicReason=newStatus==='تعلیق‌شده'?1:(req.body?.publicReason?1:0);if(!cooperationStatuses.has(newStatus))return res.status(400).json({error:'وضعیت همکاری معتبر نیست.'});if(restrictedCooperationStatuses.has(newStatus)&&reason.length<10)return res.status(400).json({error:'برای وضعیت محدودکننده، ثبت دلیل حداقل ۱۰ کاراکتری الزامی است.'});if(['عزل‌شده','محروم‌شده'].includes(newStatus)&&confirmation!=='تأیید می‌کنم')return res.status(400).json({error:'برای این عملیات حساس، عبارت تأیید می‌کنم را وارد کنید.'});if(endsAt&&Number.isNaN(Date.parse(endsAt)))return res.status(400).json({error:'تاریخ پایان معتبر نیست.'});const old=db.prepare('SELECT name,handle,cooperation_status AS status FROM brokers WHERE id=?').get(id) as {name:string;handle:string;status:string}|undefined;if(!old)return res.status(404).json({error:'فرد موردنظر پیدا نشد.'});if(old.status===newStatus)return res.status(409).json({error:'این وضعیت هم‌اکنون برای فرد فعال است.'});const active=newStatus==='فعال'?1:0;db.prepare('UPDATE brokers SET cooperation_status=?,active=?,status_reason=?,status_notes=?,status_started_at=CURRENT_TIMESTAMP,status_ends_at=?,status_applied_by=?,public_status_reason=?,public_visible=public_visible,updated_at=CURRENT_TIMESTAMP WHERE id=? AND deleted_at IS NULL').run(newStatus,active,reason||'بازگشت به فعالیت',notes,endsAt||null,admin.username,publicReason,id);db.prepare('INSERT INTO verification_history (broker_id,previous_status,new_status,admin_username,reason,notes,starts_at,ends_at,duration_label) VALUES (?,?,?,?,?,?,CURRENT_TIMESTAMP,?,?)').run(id,old.status,newStatus,admin.username,reason||'بازگشت به فعالیت',notes,endsAt||null,endsAt?'موقت':'نامحدود');db.prepare('INSERT INTO admin_notifications (title,body,target) VALUES (?,?,?)').run('تغییر وضعیت همکاری',`${old.name} (${old.handle}): ${old.status} ← ${newStatus}`,'brokers');logAdmin(admin.username,'تغییر حساس وضعیت همکاری',`${old.handle}: ${old.status} → ${newStatus} | علت: ${reason||'بازگشت به فعالیت'}`);res.json({ok:true})}catch(error){console.error('POST broker status failed',error);res.status(500).json({error:'تغییر وضعیت همکاری ممکن نشد.'})}});
app.get('/api/admin/brokers/:id/violations',(req,res)=>{try{const admin=requireAdmin(req,res);if(!admin)return;if(!canManageBrokers(admin))return res.status(403).json({error:'شما مجوز مشاهده تخلفات را ندارید.'});const rows=db.prepare(`SELECT id,title,description,status,evidence_url AS evidenceUrl,public_note AS publicNote,internal_note AS internalNote,public_visible AS publicVisible,created_by AS createdBy,created_at AS createdAt,updated_at AS updatedAt FROM broker_violations WHERE broker_id=? ORDER BY id DESC`).all(Number(req.params.id)) as any[];res.json({violations:rows.map(x=>({...x,publicVisible:Boolean(x.publicVisible),createdAt:faDate(x.createdAt),updatedAt:faDate(x.updatedAt)}))})}catch(error){console.error('GET broker violations failed',error);res.status(500).json({error:'دریافت سوابق تخلف ممکن نشد.'})}});
app.post('/api/admin/brokers/:id/violations',(req,res)=>{try{const admin=requireAdmin(req,res);if(!admin)return;if(!canManageBrokers(admin))return res.status(403).json({error:'شما مجوز ثبت تخلف را ندارید.'});const brokerId=Number(req.params.id),title=cleanText(req.body?.title,140),description=cleanText(req.body?.description,3000),status=cleanText(req.body?.status,40),evidenceUrl=cleanText(req.body?.evidenceUrl,500),publicNote=cleanText(req.body?.publicNote,1500),internalNote=cleanText(req.body?.internalNote,1500),publicVisible=req.body?.publicVisible?1:0;if(title.length<3||description.length<10||!violationStatuses.has(status))return res.status(400).json({error:'عنوان، شرح و وضعیت تخلف را کامل کنید.'});const broker=db.prepare('SELECT handle FROM brokers WHERE id=? AND deleted_at IS NULL').get(brokerId) as {handle:string}|undefined;if(!broker)return res.status(404).json({error:'فرد موردنظر پیدا نشد.'});const result=db.prepare('INSERT INTO broker_violations (broker_id,title,description,status,evidence_url,public_note,internal_note,public_visible,created_by) VALUES (?,?,?,?,?,?,?,?,?)').run(brokerId,title,description,status,evidenceUrl||null,publicNote||null,internalNote||null,publicVisible,admin.username);logAdmin(admin.username,'ثبت سابقه تخلف',`${broker.handle} · ${title} · ${status}`);res.status(201).json({ok:true,id:Number(result.lastInsertRowid)})}catch(error){console.error('POST broker violation failed',error);res.status(500).json({error:'ثبت تخلف ممکن نشد.'})}});
app.patch('/api/admin/brokers/:brokerId/violations/:id',(req,res)=>{try{const admin=requireAdmin(req,res);if(!admin)return;if(!canManageBrokers(admin))return res.status(403).json({error:'شما مجوز ویرایش تخلف را ندارید.'});const id=Number(req.params.id),brokerId=Number(req.params.brokerId),title=cleanText(req.body?.title,140),description=cleanText(req.body?.description,3000),status=cleanText(req.body?.status,40),evidenceUrl=cleanText(req.body?.evidenceUrl,500),publicNote=cleanText(req.body?.publicNote,1500),internalNote=cleanText(req.body?.internalNote,1500),publicVisible=req.body?.publicVisible?1:0;if(title.length<3||description.length<10||!violationStatuses.has(status))return res.status(400).json({error:'اطلاعات تخلف معتبر نیست.'});const result=db.prepare('UPDATE broker_violations SET title=?,description=?,status=?,evidence_url=?,public_note=?,internal_note=?,public_visible=?,updated_at=CURRENT_TIMESTAMP WHERE id=? AND broker_id=?').run(title,description,status,evidenceUrl||null,publicNote||null,internalNote||null,publicVisible,id,brokerId);if(!result.changes)return res.status(404).json({error:'سابقه تخلف پیدا نشد.'});logAdmin(admin.username,'ویرایش سابقه تخلف',`${brokerId}/${id} · ${title}`);res.json({ok:true})}catch(error){console.error('PATCH broker violation failed',error);res.status(500).json({error:'ویرایش تخلف ممکن نشد.'})}});
app.delete('/api/admin/brokers/:id',(req,res)=>{try{const admin=requireAdmin(req,res);if(!admin)return;if(!canManageBrokers(admin))return res.status(403).json({error:'شما مجوز حذف شخص را ندارید.'});const id=Number(req.params.id),reason=cleanText(req.body?.reason,500),confirmation=cleanText(req.body?.confirmation,40);if(reason.length<10)return res.status(400).json({error:'ثبت دلیل حذف با حداقل ۱۰ کاراکتر الزامی است.'});if(confirmation!=='حذف شخص')return res.status(400).json({error:'برای تأیید، عبارت حذف شخص را وارد کنید.'});const old=db.prepare('SELECT handle,cooperation_status AS status FROM brokers WHERE id=? AND deleted_at IS NULL').get(id) as {handle:string;status:string}|undefined;if(!old)return res.status(404).json({error:'فرد پیدا نشد یا قبلاً حذف شده است.'});db.prepare("UPDATE brokers SET cooperation_status='حذف‌شده',active=0,public_visible=0,deleted_at=CURRENT_TIMESTAMP,deleted_by=?,deletion_reason=?,updated_at=CURRENT_TIMESTAMP WHERE id=?").run(admin.username,reason,id);db.prepare('INSERT INTO verification_history (broker_id,previous_status,new_status,admin_username,reason,notes,starts_at,duration_label) VALUES (?,?,?,?,?,?,CURRENT_TIMESTAMP,?)').run(id,old.status,'حذف‌شده',admin.username,reason,'حذف نرم و خروج از نتایج عمومی','نامحدود');logAdmin(admin.username,'حذف نرم شخص',`${old.handle} · علت: ${reason}`);res.json({ok:true})}catch(error){console.error('DELETE broker failed',error);res.status(500).json({error:'حذف شخص ممکن نشد.'})}});
app.post('/api/admin/brokers/:id/restore',(req,res)=>{try{const admin=requireAdmin(req,res);if(!admin)return;if(!canManageBrokers(admin))return res.status(403).json({error:'شما مجوز بازیابی شخص را ندارید.'});const id=Number(req.params.id),reason=cleanText(req.body?.reason,500);if(reason.length<10)return res.status(400).json({error:'دلیل بازیابی را کامل ثبت کنید.'});const old=db.prepare('SELECT handle FROM brokers WHERE id=? AND deleted_at IS NOT NULL').get(id) as {handle:string}|undefined;if(!old)return res.status(404).json({error:'رکورد حذف‌شده پیدا نشد.'});db.prepare("UPDATE brokers SET cooperation_status='فعال',active=1,deleted_at=NULL,deleted_by=NULL,deletion_reason=NULL,status_reason=?,status_started_at=CURRENT_TIMESTAMP,status_applied_by=?,updated_at=CURRENT_TIMESTAMP WHERE id=?").run(reason,admin.username,id);db.prepare('INSERT INTO verification_history (broker_id,previous_status,new_status,admin_username,reason,notes,starts_at,duration_label) VALUES (?,?,?,?,?,?,CURRENT_TIMESTAMP,?)').run(id,'حذف‌شده','فعال',admin.username,reason,'بازیابی رکورد حذف‌شده','نامحدود');logAdmin(admin.username,'بازیابی شخص حذف‌شده',`${old.handle} · ${reason}`);res.json({ok:true})}catch(error){console.error('RESTORE broker failed',error);res.status(500).json({error:'بازیابی شخص ممکن نشد.'})}});
app.get('/api/admin/employees',(req,res)=>{
  try{const admin=requireAdmin(req,res);if(!admin)return;
    const search=cleanText(req.query.search,100);const like=`%${search}%`;
    const rows=db.prepare(`SELECT id,name,handle,employee_code AS employeeCode,verification_code AS verificationCode,department,position_title AS positionTitle,status,public_visible AS publicVisible,public_status_reason AS publicStatusReason,started_at AS startedAt,notes,created_at AS createdAt,updated_at AS updatedAt FROM employees WHERE (?='' OR name LIKE ? OR handle LIKE ? OR employee_code LIKE ? OR verification_code LIKE ?) ORDER BY id DESC`).all(search,like,like,like,like) as any[];
    res.json({employees:rows.map(x=>({...employeePublic(x),publicVisible:Boolean(x.publicVisible),notes:x.notes||'',createdAt:faDate(x.createdAt)}))});
  }catch(error){console.error('GET admin employees failed',error);res.status(500).json({error:'دریافت کارمندان ممکن نشد.'})}
});
app.post('/api/admin/employees',(req,res)=>{
  try{const admin=requireAdmin(req,res);if(!admin)return;
    const name=cleanText(req.body?.name,80),handle=cleanText(req.body?.handle,80),department=cleanText(req.body?.department,80)||'عملیات',positionTitle=cleanText(req.body?.positionTitle,80)||'کارمند';
    if(name.length<2||!/^@[A-Za-z0-9_]+$/.test(handle))return res.status(400).json({error:'نام و شناسه کارمند معتبر نیست.'});
    const result=db.prepare('INSERT INTO employees (name,handle,department,position_title,started_at,notes) VALUES (?,?,?,?,?,?)').run(name,handle,department,positionTitle,cleanText(req.body?.startedAt,30)||null,cleanText(req.body?.notes,1000)||null);
    const id=Number(result.lastInsertRowid);db.prepare('UPDATE employees SET employee_code=?,verification_code=? WHERE id=?').run(entityCode('EMP',id),entityCode('EVR',id),id);
    logAdmin(admin.username,'افزودن کارمند',`${name} · ${handle}`);res.status(201).json({ok:true,id});
  }catch(error:any){console.error('POST employee failed',error);res.status(error?.code==='ERR_SQLITE_CONSTRAINT_UNIQUE'?409:500).json({error:error?.code==='ERR_SQLITE_CONSTRAINT_UNIQUE'?'این شناسه قبلاً ثبت شده است.':'افزودن کارمند ممکن نشد.'})}
});
app.patch('/api/admin/employees/:id',(req,res)=>{
  try{const admin=requireAdmin(req,res);if(!admin)return;const id=Number(req.params.id);const current=db.prepare('SELECT * FROM employees WHERE id=?').get(id) as any;if(!current)return res.status(404).json({error:'کارمند پیدا نشد.'});
    const fields={name:req.body?.name===undefined?current.name:cleanText(req.body.name,80),handle:req.body?.handle===undefined?current.handle:cleanText(req.body.handle,80),department:req.body?.department===undefined?current.department:cleanText(req.body.department,80),position_title:req.body?.positionTitle===undefined?current.position_title:cleanText(req.body.positionTitle,80),status:req.body?.status===undefined?current.status:cleanText(req.body.status,30),public_visible:req.body?.publicVisible===undefined?current.public_visible:(req.body.publicVisible?1:0),public_status_reason:req.body?.publicStatusReason===undefined?current.public_status_reason:cleanText(req.body.publicStatusReason,500),started_at:req.body?.startedAt===undefined?current.started_at:cleanText(req.body.startedAt,30),notes:req.body?.notes===undefined?current.notes:cleanText(req.body.notes,1000)};
    if(!fields.name||!/^@[A-Za-z0-9_]+$/.test(fields.handle)||!['فعال','غیرفعال','تعلیق‌شده'].includes(fields.status))return res.status(400).json({error:'اطلاعات کارمند معتبر نیست.'});
    db.prepare('UPDATE employees SET name=?,handle=?,department=?,position_title=?,status=?,public_visible=?,public_status_reason=?,started_at=?,notes=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(fields.name,fields.handle,fields.department,fields.position_title,fields.status,fields.public_visible,fields.public_status_reason||null,fields.started_at||null,fields.notes||null,id);
    logAdmin(admin.username,'ویرایش کارمند',String(id));res.json({ok:true});
  }catch(error:any){console.error('PATCH employee failed',error);res.status(error?.code==='ERR_SQLITE_CONSTRAINT_UNIQUE'?409:500).json({error:error?.code==='ERR_SQLITE_CONSTRAINT_UNIQUE'?'این شناسه قبلاً ثبت شده است.':'ویرایش کارمند ممکن نشد.'})}
});
app.delete('/api/admin/employees/:id',(req,res)=>{
  try{const admin=requireAdmin(req,res);if(!admin)return;const id=Number(req.params.id);const result=db.prepare('DELETE FROM employees WHERE id=?').run(id);if(result.changes===0)return res.status(404).json({error:'کارمند پیدا نشد.'});logAdmin(admin.username,'حذف کارمند',String(id));res.json({ok:true})}
  catch(error){console.error('DELETE employee failed',error);res.status(500).json({error:'حذف کارمند ممکن نشد.'})}
});

app.get('/api/admin/notices',(req,res)=>{if(!requireAdmin(req,res))return;const rows=db.prepare('SELECT id,title,body,active FROM notices ORDER BY id DESC').all() as any[];res.json({notices:rows.map(x=>({...x,active:Boolean(x.active)}))})});
app.post('/api/admin/notices',(req,res)=>{try{const admin=requireAdmin(req,res);if(!admin)return;const title=cleanText(req.body?.title,100),body=cleanText(req.body?.body,1000);if(!title||!body)return res.status(400).json({error:'عنوان و متن لازم است.'});db.prepare('INSERT INTO notices (title,body) VALUES (?,?)').run(title,body);logAdmin(admin.username,'انتشار اطلاعیه',title);res.status(201).json({ok:true})}catch(error){console.error('POST notice failed',error);res.status(500).json({error:'انتشار اطلاعیه ممکن نشد.'})}});
app.patch('/api/admin/notices/:id',(req,res)=>{try{const admin=requireAdmin(req,res);if(!admin)return;const id=Number(req.params.id);const current=db.prepare('SELECT title,body,active FROM notices WHERE id=?').get(id) as {title:string;body:string;active:number}|undefined;if(!current)return res.status(404).json({error:'اطلاعیه پیدا نشد.'});const title=req.body?.title===undefined?current.title:cleanText(req.body.title,100),body=req.body?.body===undefined?current.body:cleanText(req.body.body,1000),active=req.body?.active===undefined?current.active:(req.body.active?1:0);if(!title||!body)return res.status(400).json({error:'عنوان و متن اطلاعیه لازم است.'});db.prepare('UPDATE notices SET title=?,body=?,active=? WHERE id=?').run(title,body,active,id);logAdmin(admin.username,'ویرایش اطلاعیه',`${id}: ${title}`);res.json({ok:true})}catch(error){console.error('PATCH notice failed',error);res.status(500).json({error:'تغییر اطلاعیه ممکن نشد.'})}});
app.delete('/api/admin/notices/:id',(req,res)=>{try{const admin=requireAdmin(req,res);if(!admin)return;const id=Number(req.params.id);const result=db.prepare('DELETE FROM notices WHERE id=?').run(id);if(result.changes===0)return res.status(404).json({error:'اطلاعیه پیدا نشد.'});logAdmin(admin.username,'حذف اطلاعیه',String(id));res.json({ok:true})}catch(error){console.error('DELETE notice failed',{id:req.params.id,error});res.status(500).json({error:'حذف اطلاعیه ممکن نشد.'})}});

app.use('/api',(req,res)=>res.status(404).json({error:'مسیر درخواستی پیدا نشد.'}));

// Serve the built React app from the same Render web service.
const clientDist = path.resolve(process.cwd(), 'dist');
app.use(express.static(clientDist));
app.get(/.*/, (_req, res) => {
  res.sendFile(path.join(clientDist, 'index.html'));
});
app.use((error: unknown, req: Request, res: Response, _next: NextFunction) => { console.error('Unhandled API error',{path:req.path,error});res.status(500).json({error:'خطای پیش‌بینی‌نشده رخ داد.'}); });

const port=Number(process.env.PORT||3001);
app.listen(port,()=>console.log(`Vaseteh server listening on ${port}`));
