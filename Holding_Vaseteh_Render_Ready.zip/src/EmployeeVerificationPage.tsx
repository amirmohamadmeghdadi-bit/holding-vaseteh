import { FormEvent, useEffect, useState } from 'react';
import { AlertTriangle, BadgeCheck, BriefcaseBusiness, CheckCircle2, Search, ShieldCheck, UserCheck } from 'lucide-react';

type Employee = {
  id:number; name:string; handle:string; employeeCode:string; verificationCode:string;
  department:string; positionTitle:string; status:string; publicStatusReason?:string;
  startedAt?:string; updatedAt:string; checkedAt?:string;
};
type Response = {found:boolean; result?:Employee; message?:string};

async function request<T>(path:string, options?:RequestInit):Promise<T>{
  const r=await fetch(path,{...options,headers:{'Content-Type':'application/json',...(options?.headers||{})}});
  const d=await r.json().catch(()=>({}));
  if(!r.ok) throw new Error(d.error||'انجام درخواست ممکن نشد.');
  return d as T;
}
const statusClass=(s:string)=>s==='فعال'?'is-active':s==='تعلیق‌شده'?'is-suspended':'is-off';

function EmployeeCard({item}:{item:Employee}) {
  return <article className="employee-result">
    <div className="employee-result-head"><div className="employee-avatar"><UserCheck/></div><div><span>نتیجه رسمی سامانه</span><h2>{item.name}</h2><code dir="ltr">{item.handle}</code></div><b className={`verification-status ${statusClass(item.status)}`}>{item.status}</b></div>
    <div className="employee-details">
      <div><small>سمت</small><strong>{item.positionTitle}</strong></div>
      <div><small>واحد</small><strong>{item.department}</strong></div>
      <div><small>کد کارمند</small><strong dir="ltr">{item.employeeCode}</strong></div>
      <div><small>کد استعلام</small><strong dir="ltr">{item.verificationCode}</strong></div>
      <div><small>شروع همکاری</small><strong>{item.startedAt||'ثبت نشده'}</strong></div>
      <div><small>آخرین بروزرسانی</small><strong>{item.updatedAt}</strong></div>
    </div>
    {item.status!=='فعال'&&<div className="employee-warning"><AlertTriangle/><div><strong>وضعیت همکاری: {item.status}</strong><p>{item.publicStatusReason||'دلیل عمومی برای این وضعیت ثبت نشده است.'}</p></div></div>}
    <div className="verification-disclaimer"><AlertTriangle/><p>این استعلام فقط وضعیت ثبت‌شده در سامانه را نشان می‌دهد و به‌تنهایی تضمین عملکرد، معامله یا مسئولیت حقوقی شخص نیست.</p></div>
  </article>;
}

export default function EmployeeVerificationPage(){
  const [query,setQuery]=useState(''); const [result,setResult]=useState<Response|null>(null); const [items,setItems]=useState<Employee[]>([]);
  const [loading,setLoading]=useState(false); const [error,setError]=useState(''); const [filter,setFilter]=useState('');
  useEffect(()=>{request<{employees:Employee[]}>('/api/employee-verification/directory').then(r=>setItems(r.employees)).catch(()=>{})},[]);
  const submit=async(e:FormEvent)=>{e.preventDefault();if(query.trim().length<2){setError('شناسه یا کد کارمند را وارد کنید.');return}setLoading(true);setError('');setResult(null);try{setResult(await request<Response>('/api/employee-verification/'+encodeURIComponent(query.trim())))}catch(err){setError((err as Error).message)}finally{setLoading(false)}};
  const shown=items.filter(x=>!filter||x.department===filter);
  const departments=[...new Set(items.map(x=>x.department))];
  return <div className="verification-page employee-page">
    <section className="verification-hero"><div className="container verification-hero-inner">
      <div className="verification-kicker"><ShieldCheck size={18}/> Employee Verification</div>
      <h1>استعلام کارمندان</h1>
      <p>وضعیت و سمت ثبت‌شده اعضای کارکنان مجموعه را مستقیماً از سامانه بررسی کنید.</p>
      <form className="verification-search" onSubmit={submit}><label><span>شناسه روبیکا، کد کارمند یا کد استعلام</span><div><Search/><input dir="ltr" value={query} onChange={e=>setQuery(e.target.value)} placeholder="@Username / EMP-... / EVR-..."/></div></label><button className="btn-primary" disabled={loading}>{loading?'در حال بررسی…':'استعلام'}<Search size={18}/></button></form>
    </div></section>
    <div className="container verification-content">
      {error&&<div className="verification-error"><AlertTriangle/><p>{error}</p></div>}
      {result&&!result.found&&<div className="verification-empty"><AlertTriangle/><h2>کارمند یافت نشد</h2><p>{result.message}</p></div>}
      {result?.found&&result.result&&<EmployeeCard item={result.result}/>}
      <section className="employee-directory"><div className="directory-head"><div><span>فهرست عمومی</span><h2>کارمندان قابل استعلام</h2><p>فقط اطلاعاتی که مدیریت برای انتشار عمومی فعال کرده نمایش داده می‌شود.</p></div><select value={filter} onChange={e=>setFilter(e.target.value)}><option value="">همه واحدها</option>{departments.map(d=><option key={d}>{d}</option>)}</select></div>
        {shown.length===0?<div className="verification-empty"><BriefcaseBusiness/><p>موردی برای نمایش وجود ندارد.</p></div>:<div className="employee-grid">{shown.map(x=><button key={x.id} onClick={()=>{setQuery(x.verificationCode);setResult({found:true,result:x})}}><div className="employee-avatar"><BadgeCheck/></div><div><h3>{x.name}</h3><code dir="ltr">{x.handle}</code><small>{x.positionTitle} · {x.department}</small></div><span className={`verification-status ${statusClass(x.status)}`}>{x.status}</span></button>)}</div>}
      </section>
    </div>
  </div>;
}
