import { FormEvent, ReactNode, useEffect, useMemo, useState } from 'react';
import { BrowserRouter, Link, NavLink, Route, Routes, useLocation, useNavigate } from 'react-router-dom';
import {
  AlertTriangle, ArrowLeft, BadgeCheck, BookOpen, BriefcaseBusiness, CheckCircle2,
  ChevronLeft, CircleUserRound, Clock3, FileCheck2, FileText, Gavel, Headphones,
  Home, Landmark, LockKeyhole, Mail, Menu, MessageCircle, MessagesSquare, Phone,
  Plus, Search, Send, Shield, ShieldAlert, Sparkles, UserCheck, Users, X
} from 'lucide-react';
import { activities, categories, initialBrokers, navItems, requiredEvidence, rules, type Broker } from './data';
import AdminCenter from './AdminCenter';
import VerificationPage, { DiscrepancyReportPage, PartnerProfilePage } from './VerificationPage';
import EmployeeVerificationPage from './EmployeeVerificationPage';

type User = { id: number; name: string; username: string; unread: number };
type Message = { id: number; sender: 'user' | 'admin'; body: string; createdAt: string; attachmentUrl?: string };
type Conversation = { id: number; subject: string; status: string; unreadUser: number; unreadAdmin: number; userName?: string; username?: string; messages: Message[] };
type Notice = { id: number; title: string; body: string; active: boolean };

async function api<T>(path: string, options?: RequestInit): Promise<T> {
  const response = await fetch(path, {
    ...options,
    headers: { 'Content-Type': 'application/json', ...(options?.headers || {}) },
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || 'ارتباط با سامانه برقرار نشد.');
  return data as T;
}

async function uploadChatFile(file: File, headers: Record<string,string> = {}) {
  const allowed = ['image/jpeg','image/png','image/webp','image/gif','video/mp4','video/webm','video/quicktime'];
  if (!allowed.includes(file.type)) throw new Error('فقط عکس و ویدئو قابل ارسال است.');
  if (file.size > 15 * 1024 * 1024) throw new Error('حداکثر حجم فایل ۱۵ مگابایت است.');
  const data = await new Promise<string>((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result));reader.onerror=()=>reject(new Error('خواندن فایل ممکن نشد.'));reader.readAsDataURL(file)});
  return api<{url:string;fileName:string;mimeType:string}>('/api/uploads',{method:'POST',headers,body:JSON.stringify({fileName:file.name,mimeType:file.type,data})});
}

const rubikaUrl = (handle: string) => `https://rubika.ir/${handle.replace('@', '')}`;

function RubikaButton({ href, children, testId, secondary = false }: { href: string; children: ReactNode; testId: string; secondary?: boolean }) {
  return (
    <a data-testid={testId} href={href} target="_blank" rel="noreferrer" className={secondary ? 'btn-secondary' : 'btn-primary'}>
      {children}<ArrowLeft size={18} />
    </a>
  );
}

function SectionTitle({ eyebrow, title, description }: { eyebrow?: string; title: string; description?: string }) {
  return <div className="section-title reveal"><div className="eyebrow"><Sparkles size={15} />{eyebrow}</div><h2>{title}</h2>{description && <p>{description}</p>}</div>;
}

function Breadcrumb({ current }: { current: string }) {
  return <div className="breadcrumb" data-testid="breadcrumb"><Link to="/">صفحه اصلی</Link><ChevronLeft size={15} /><span>{current}</span></div>;
}

function PageHero({ title, description, icon }: { title: string; description: string; icon: ReactNode }) {
  return <div className="page-hero"><div className="page-hero-icon">{icon}</div><div><h1>{title}</h1><p>{description}</p></div></div>;
}

function Warning({ title, children }: { title: string; children: ReactNode }) {
  return <div className="warning-card"><ShieldAlert size={25} /><div><strong>{title}</strong><p>{children}</p></div></div>;
}

function Header({ user, onLogout }: { user: User | null; onLogout: () => void }) {
  const [open, setOpen] = useState(false);
  const location = useLocation();
  useEffect(() => setOpen(false), [location.pathname]);
  return <header className="site-header">
    <div className="nav-shell">
      <Link to="/" className="brand" data-testid="header-logo"><span>⚜️</span><div><strong>هلدینگ واسطه‌گری</strong><small>انجمن رسمی روبیکا</small></div></Link>
      <nav className="desktop-nav" aria-label="منوی اصلی">{navItems.map(item => <NavLink data-testid={`nav-${item.path.replace('/', '') || 'home'}`} key={item.path} to={item.path}>{item.label}</NavLink>)}</nav>
      <div className="header-actions">
        <Link to="/account" className="account-link" data-testid="account-link"><CircleUserRound size={20}/><span>{user ? user.name : 'ورود کاربران'}</span>{user && user.unread > 0 && <b>{user.unread}</b>}</Link>
        {user && <button className="logout-mini" onClick={onLogout} data-testid="header-logout">خروج</button>}
        <button className="menu-btn" aria-label="نمایش منو" aria-expanded={open} onClick={() => setOpen(!open)} data-testid="mobile-menu-toggle">{open ? <X/> : <Menu/>}</button>
      </div>
    </div>
    {open && <div className="mobile-menu" data-testid="mobile-menu">{navItems.map(item => <NavLink key={item.path} to={item.path}>{item.label}</NavLink>)}<Link to="/account">{user ? 'پیام‌های من' : 'ورود و عضویت'}</Link></div>}
  </header>;
}

function Footer() {
  return <footer className="footer"><div className="container footer-grid">
    <div><div className="brand footer-brand"><span>⚜️</span><div><strong>هلدینگ واسطه‌گری</strong><small>انجمن رسمی روبیکا</small></div></div><p>مجموعه‌ای مستقل و غیردولتی در بستر روبیکا با هدف افزایش آگاهی کاربران، سامان‌دهی گزارشات و بررسی منظم مستندات.</p></div>
    <div><h3>دسترسی سریع</h3><div className="footer-links">{navItems.map(item => <Link data-testid={`footer-${item.path.replace('/', '') || 'home'}`} key={item.path} to={item.path}>{item.label}</Link>)}</div></div>
    <div><h3>لینک رسمی</h3><a className="official-handle" href="https://rubika.ir/AnJvMaN" target="_blank" rel="noreferrer" data-testid="footer-official">@AnJvMaN</a><div className="legal-links"><Link to="/terms" data-testid="footer-terms">شرایط استفاده</Link><Link to="/privacy" data-testid="footer-privacy">حریم خصوصی</Link><Link to="/admin" data-testid="footer-admin">ورود مدیریت</Link></div></div>
  </div><div className="container footer-warning"><strong>هشدار حقوقی:</strong> درج نام، شناسه یا گزارش درباره یک شخص به‌تنهایی به معنای صدور حکم قضایی یا اثبات قطعی جرم نیست. مسئولیت بررسی اطلاعات و تصمیم‌گیری درباره معاملات بر عهده کاربران است.</div><div className="copyright">© تمامی حقوق محتوایی و طراحی برای هلدینگ واسطه‌گری / انجمن رسمی روبیکا محفوظ است.</div></footer>;
}

function Layout({ user, onLogout, children }: { user: User | null; onLogout: () => void; children: ReactNode }) {
  const { pathname } = useLocation();
  useEffect(() => { window.scrollTo({ top: 0, behavior: 'smooth' }); }, [pathname]);
  return <div className="app-shell"><Header user={user} onLogout={onLogout}/><main>{children}</main><Footer/></div>;
}

function HomePage({ notices }: { notices: Notice[] }) {
  return <>
    <section className="hero"><div className="hero-orb orb-one"/><div className="hero-orb orb-two"/><div className="container hero-grid"><div className="hero-copy"><div className="hero-badge"><BadgeCheck size={18}/> مرجع مستقل ثبت و بررسی گزارشات</div><h1><span>⚜️</span> هلدینگ<br/><em>واسطه‌گری</em></h1><h2>انجمن رسمی روبیکا</h2><p>مرجع ثبت و بررسی گزارشات، معرفی واسطه‌ها، مدیریت ارتباطات و هماهنگی مجموعه؛ با تأکید بر مستندات، شفافیت و آگاهی کاربران.</p><div className="hero-actions"><RubikaButton href="https://rubika.ir/AnJvMaN" testId="hero-enter">ورود به انجمن</RubikaButton><Link to="/reports" className="btn-secondary" data-testid="hero-report">ثبت گزارش تخلفات<FileText size={18}/></Link></div><div className="trust-row"><span><Shield size={18}/> مستقل و غیردولتی</span><span><FileCheck2 size={18}/> بررسی مستندات</span><span><Gavel size={18}/> تفکیک گزارش از حکم</span></div></div><div className="hero-panel"><div className="crest">⚜️</div><p>فعالیت از سال</p><strong>۱۴۰۰</strong><div className="gold-line"/><ul><li>ثبت و سامان‌دهی گزارشات</li><li>معرفی واسطه‌های مجموعه</li><li>افزایش آگاهی پیش از معامله</li></ul></div></div></section>
    {notices.length > 0 && <section className="container notices" data-testid="public-notices">{notices.map(n => <div key={n.id}><AlertTriangle size={20}/><strong>{n.title}</strong><span>{n.body}</span></div>)}</section>}
    <section className="section container"><SectionTitle eyebrow="مأموریت انجمن" title="آگاهی بیشتر، معامله آگاهانه‌تر" description="هدف اصلی، ایجاد مرجعی منظم برای ثبت و بررسی گزارش‌های کاربران و کمک به تصمیم‌گیری دقیق‌تر پیش از معامله است."/><div className="feature-grid">{activities.map((item, i) => <div className="feature-card" key={item}><span>{String(i + 1).padStart(2, '۰')}</span><CheckCircle2/><p>{item}</p></div>)}</div></section>
    <section className="section surface"><div className="container split"><div><SectionTitle eyebrow="فرآیند بررسی" title="هر ادعا، یک نتیجه قطعی نیست"/><p className="body-copy">انجمن میان «ادعا»، «گزارش» و «نتیجه بررسی» تفاوت قائل می‌شود. گزارش‌ها باید با مدارک پشتیبانی شوند و نتیجه تنها بر اساس اطلاعات موجود در پرونده اعلام می‌شود.</p><Warning title="مدرک کافی ضروری است">گزارش‌های بدون مدرک، ناقص، مبهم یا فاقد اطلاعات قابل بررسی ممکن است ثبت یا منتشر نشوند.</Warning></div><div className="evidence-card"><h3><FileCheck2/> مستندات قابل بررسی</h3>{requiredEvidence.map(item => <div key={item}><CheckCircle2 size={17}/><span>{item}</span></div>)}</div></div></section>
    <section className="section container"><div className="principles"><div><Landmark/><h3>ماهیت فعالیت</h3><p>این انجمن مجموعه‌ای مستقل و غیردولتی است و وابستگی یا نمایندگی رسمی از دولت، قوه قضائیه، پلیس، نهادهای امنیتی یا شرکت روبیکا ندارد.</p></div><div><Shield/><h3>حفظ نظم و اعتبار</h3><p>هدف، اطلاع‌رسانی مستند و منظم است؛ نه ایجاد درگیری، توهین یا تشویق کاربران به برخورد شخصی با افراد.</p></div><div><Gavel/><h3>حدود حقوقی</h3><p>ثبت آیدی یا اطلاعات یک شخص، حکم قضایی یا اثبات قطعی جرم نیست. تصمیم نهایی در امور قانونی با مراجع رسمی کشور است.</p></div></div></section>
    <section className="cta-section"><div className="container"><div><span>🔰 انجمن رسمی روبیکا</span><h2>مسیر رسمی ارتباط با انجمن</h2><p>تنها آیدی اصلی انجمن <b dir="ltr">@AnJvMaN</b> است. برای جلوگیری از لینک‌های جعلی فقط از دکمه زیر استفاده کنید.</p></div><RubikaButton href="https://rubika.ir/AnJvMaN" testId="home-final-cta">ورود به انجمن رسمی</RubikaButton></div></section>
  </>;
}

function AboutPage() {
  return <div className="container page"><Breadcrumb current="معرفی انجمن"/><PageHero icon={<Landmark/>} title="معرفی انجمن رسمی روبیکا" description="ساختاری مستقل برای دریافت گزارش، بررسی مستندات و افزایش آگاهی کاربران در معاملات روبیکا."/>
    <section className="content-card"><h2>داستان و مأموریت مجموعه</h2><p>انجمن رسمی روبیکا فعالیت خود را از سال ۱۴۰۰ آغاز کرده و طی سال‌های فعالیت تلاش داشته بستری منظم برای دریافت گزارش‌های کاربران و بررسی مستندات مربوط به اختلافات، سوءاستفاده‌ها، کلاهبرداری‌های ادعایی و سایر تخلفات مرتبط با معاملات ایجاد کند.</p><p>اطلاعات پرونده‌ها پس از بررسی اولیه دسته‌بندی می‌شوند تا کاربران بتوانند هنگام انجام معاملات با دقت و آگاهی بیشتری تصمیم بگیرند.</p></section>
    <section className="section"><SectionTitle eyebrow="اصول بنیادین" title="چارچوب فعالیت انجمن"/><div className="principles"><div><FileCheck2/><h3>توجه به مستندات</h3><p>هر پرونده بر پایه اطلاعات و مدارک قابل بررسی ارزیابی می‌شود.</p></div><div><BadgeCheck/><h3>شفافیت گزارشات</h3><p>ادعا، گزارش و نتیجه بررسی به‌صورت روشن از یکدیگر تفکیک می‌شوند.</p></div><div><Users/><h3>آگاهی کاربران</h3><p>کاربر پیش از معامله باید شخصاً هویت و اعتبار طرف مقابل را بررسی کند.</p></div></div></section>
    <Warning title="عنوان انجمن رسمی روبیکا">این عبارت نام فعالیت مجموعه در بستر روبیکا است و به معنای نمایندگی رسمی شرکت روبیکا یا نهادهای دولتی نیست.</Warning>
  </div>;
}

function BrokersPage() {
  const [brokers, setBrokers] = useState<Broker[]>(initialBrokers);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const load = () => { setLoading(true); setError(''); api<{ brokers: Broker[] }>('/api/brokers').then(r => setBrokers(r.brokers)).catch(e => setError(e.message)).finally(() => setLoading(false)); };
  useEffect(load, []);
  return <div className="container page"><Breadcrumb current="واسطه‌های ارشد"/><PageHero icon={<UserCheck/>} title="مرجع واسطه‌های ارشد روبیکا" description="فهرست واسطه‌های معرفی‌شده توسط مجموعه؛ پیش از هر معامله، وضعیت فعلی را از انجمن استعلام کنید."/>
    {loading && <div className="skeleton-grid" data-testid="brokers-loading">{[1,2,3,4].map(i => <div key={i}/>)}</div>}
    {error && <div className="error-state" data-testid="brokers-error"><AlertTriangle/><p>{error}</p><button onClick={load} data-testid="brokers-retry">تلاش دوباره</button></div>}
    {!loading && !error && <div className="broker-grid" data-testid="brokers-list">{brokers.filter(b => b.active).map(b => <article className="broker-card" key={b.id}><div className="broker-icon">⚖️</div><div><small>واسطه معرفی‌شده</small><h2>{b.name}</h2><code dir="ltr">{b.handle}</code></div><RubikaButton href={rubikaUrl(b.handle)} testId={`broker-${b.id}`} secondary>ورود / ارتباط</RubikaButton></article>)}</div>}
    <section className="section"><SectionTitle eyebrow="پیش از معامله" title="دو اقدام ضروری"/><div className="steps-grid"><div><b>۱</b><h3>بررسی آخرین فهرست</h3><p>از به‌روز بودن اطلاعات مطمئن شوید و هر ابهام را فقط از مسیر رسمی انجمن پیگیری کنید.</p></div><div><b>۲</b><h3>دریافت استعلام واسطه</h3><p>بدون استعلام معامله نکنید؛ افراد سودجو ممکن است با هویت جعلی یا حساب مشابه فعالیت کنند.</p></div></div></section>
    <Warning title="مسئولیت بررسی با کاربر است">معرفی در این صفحه جایگزین بررسی مجدد و دریافت استعلام در زمان انجام معامله نیست.</Warning>
  </div>;
}

function AlliancePage() {
  return <div className="container page"><Breadcrumb current="تیم رسمی اتحاد"/><PageHero icon={<Users/>} title="تیم رسمی اتحاد انجمن" description="مسیرهای رسمی ورود به تیم‌های اتحاد و نکات امنیتی ضروری پیش از هر همکاری."/>
    <Warning title="اطلاعیه اعتبارسنجی">واسطه‌های معرفی‌شده بر اساس فهرست داخلی مجموعه هستند. پیش از هر معامله آخرین وضعیت را از مسیر رسمی انجمن استعلام کنید.</Warning>
    <div className="numbered-list">{['فهرست واسطه‌های رسمی را بررسی و از به‌روز بودن آن اطمینان حاصل کنید.','برای سؤال یا تردید، فقط از طریق پیام خصوصی به ادمین انجمن مراجعه کنید.','پیش از معامله استعلام اعتبار بگیرید تا احتمال سوءاستفاده با حساب جعلی کاهش یابد.'].map((x,i)=><div key={x}><span>{i+1}</span><p>{x}</p></div>)}</div>
    <div className="team-grid"><div className="team-card blue"><Users/><h2>تیم اتحاد ۱</h2><p>مسیر رسمی ورود به تیم نخست اتحاد انجمن</p><RubikaButton href="https://rubika.ir/TeAm_AnJvMaN" testId="alliance-team-1">ورود به تیم اتحاد ۱</RubikaButton></div><div className="team-card gold"><Users/><h2>تیم اتحاد ۲</h2><p>مسیر رسمی ورود به تیم دوم اتحاد انجمن</p><RubikaButton href="https://rubika.ir/TeAmE_AnJvMaN" testId="alliance-team-2">ورود به تیم اتحاد ۲</RubikaButton></div></div>
    <Warning title="هشدار امنیتی بسیار مهم">انجمن در قبال معاملات با افراد خارج از فهرست رسمی یا واسطه‌های تأییدنشده مسئولیتی ندارد. بررسی نهایی بر عهده کاربر است.</Warning>
  </div>;
}

function MembershipPage() {
  const docs = ['شناسنامه یا مدرک هویتی معتبر','شماره تلفن همراه فعال و در دسترس','شناسه یا شماره حساب کاربری روبیکا','شماره کارت بانکی مورد استفاده در معاملات','دست‌نوشته احراز هویت کنار مدرک هویتی','تصویر موقعیت مکانی یا اسکرین‌شات Location'];
  return <div className="container page"><Breadcrumb current="شرایط عضویت"/><PageHero icon={<FileCheck2/>} title="آیین‌نامه احراز هویت و پذیرش اعضا" description="الزامات، مراحل و ضوابط پذیرش عضو با هدف حفظ امنیت، شفافیت و اعتماد متقابل."/>
    <section className="content-card"><span className="step-label">مرحله ۱</span><h2>الزامات احراز هویت</h2><p>تمامی متقاضیان باید پیش از ثبت درخواست، فرآیند احراز هویت را کامل و مدارک لازم را به‌صورت واضح و بدون ویرایش ارائه کنند.</p><div className="check-grid">{docs.map(x=><div key={x}><CheckCircle2/>{x}</div>)}</div><RubikaButton href="https://rubika.ir/ShaRaYeT_AnJvMaN/BGGBIFHDCJAFAFBJ" testId="membership-handwriting" secondary>مشاهده متن دست‌نوشته</RubikaButton><p className="note">درج تاریخ و ساعت دقیق همان روز و اعلام واضح هدف احراز هویت در ویدئو الزامی است.</p></section>
    <section className="content-card"><span className="step-label">مرحله ۲</span><h2>درج تگ رسمی انجمن</h2><p>پس از ارائه مدارک، تگ <b dir="ltr">@AnJvMaN</b> باید در بیوگرافی حساب درج شود. حذف یا تغییر آن پیش از تکمیل تأیید می‌تواند موجب توقف درخواست شود.</p></section>
    <section className="content-card"><span className="step-label">مرحله ۳</span><h2>ارسال جهت بررسی نهایی</h2><p>مدارک در کانال تعیین‌شده منتشر و لینک آن برای مدیریت ارسال می‌شود. تنها پس از تأیید رسمی، عضویت معتبر خواهد بود.</p></section>
    <section className="section"><SectionTitle eyebrow="تبصره‌ها" title="نکات مهم و قابل توجه"/><div className="terms-grid">{['مدارک ناقص، مخدوش، غیرواقعی یا متعلق به دیگری موجب رد درخواست است.','اطلاعات نادرست، مدارک جعلی یا پنهان‌کردن سابقه تخلف موجب محرومیت می‌شود.','انجمن می‌تواند در صورت ابهام مدارک تکمیلی درخواست کند یا از پذیرش خودداری نماید.','عضویت به‌منزله پذیرش قوانین، مقررات و تصمیمات مدیریت مجموعه است.'].map((x,i)=><div key={x}><b>تبصره {i+1}</b><p>{x}</p></div>)}</div></section>
    <div className="center-action"><RubikaButton href="https://rubika.ir/ShaRaYeT_AnJvMaN" testId="membership-join">شرایط پیوستن به تیم انجمن</RubikaButton></div>
  </div>;
}

function ChatsPage() {
  const chats = [
    { icon: '🟡', title: 'گروه چت اصلی انجمن', text: 'مرجع اصلی گفتگو، اطلاع‌رسانی و ارتباط اعضا', href: 'https://rubika.ir/cHaT_AnJvMaN/BGFEDIIAIHBBGFIJ' },
    { icon: '🔴', title: 'گروه چت زاپاس انجمن', text: 'حفظ دسترسی کاربران در شرایط اضطراری', href: 'https://rubika.ir/cHaT_AnJvMaN/BGFHIBBHEEADDFIJ' },
    { icon: '🔵', title: 'گروه چت شبانه انجمن', text: 'فضایی برای گفتگو و تعامل در ساعات شب', href: 'https://rubika.ir/cHaT_AnJvMaN/BGGACBGIGDIGDFIJ' },
  ];
  return <div className="container page"><Breadcrumb current="گپ‌های انجمن"/><PageHero icon={<MessagesSquare/>} title="گروه‌های گفتگوی انجمن سراسری" description="لینک‌های رسمی برای ارتباط منظم، هماهنگی اعضا و گفتگو در محیط‌های معرفی‌شده مجموعه."/>
    <div className="chat-links">{chats.map((c,i)=><article key={c.title}><span>{c.icon}</span><h2>{c.title}</h2><p>{c.text}</p><RubikaButton href={c.href} testId={`chat-group-${i+1}`}>ورود به گروه</RubikaButton></article>)}</div>
    <section className="content-card"><h2><Shield/> مدیریت گروه‌های گفتگو</h2><p>نظارت بر نظم گروه‌ها، مشکلات دسترسی، گزارش افراد متخلف و هماهنگی امور گپ‌ها بر عهده مدیران رسمی مجموعه است. مشکلات ورود، خرابی لینک، محدودشدن دسترسی یا درخواست تغییر مدیریتی را فقط از مسیر رسمی پیگیری کنید.</p></section>
  </div>;
}

function RulesPage() {
  return <div className="container page"><Breadcrumb current="قوانین"/><PageHero icon={<Gavel/>} title="قوانین هلدینگ واسطه‌گری" description="چارچوب رسیدگی به تخلفات، گزارشات و اختلافات معاملاتی در انجمن واسطه‌های روبیکا."/>
    <div className="rules-list">{rules.map((r,i)=><article key={r[0]}><span>{String(i+1).padStart(2,'۰')}</span><div><h2>{r[0]}</h2><p>{r[1]}</p></div></article>)}</div>
    <section className="content-card"><h2>اصول فعالیت انجمن</h2><div className="check-grid">{['بررسی هر پرونده بر اساس مدارک انجام می‌شود.','صرف ادعا به‌تنهایی دلیل اثبات تخلف نیست.','طرفین باید توضیحات و مدارک کامل ارائه کنند.','هیچ فردی صرفاً بر اساس ادعای یک طرف متخلف شناخته نمی‌شود.','اطلاعات کاربران تا حد امکان با رعایت حریم خصوصی نگهداری می‌شود.','ارائه مدارک جعلی و اتهام بدون مدرک ممنوع است.'].map(x=><div key={x}><CheckCircle2/>{x}</div>)}</div></section>
    <Warning title="صلاحیت قانونی">انجمن صلاحیت قضایی یا انتظامی رسمی ندارد. در صورت وقوع جرم، موضوع را از مراجع قانونی یا پلیس فتا با شماره ۰۹۶۳۸۰ پیگیری کنید.</Warning>
    <div className="center-action"><RubikaButton href="https://rubika.ir/AnJvMaN/BIDHGAGCHD" testId="rules-rubika">قوانین هلدینگ در روبیکا</RubikaButton></div>
  </div>;
}

function ReportsPage() {
  return <div className="container page"><Breadcrumb current="گزارش تخلفات"/><div className="report-banner"><ShieldAlert/><div><span>🚨 ثبت و بررسی گزارش تخلفات</span><h1>ارائه مستندات کامل = بررسی دقیق‌تر گزارش</h1><p>پیش از ارسال درخواست، شرایط و ضوابط را با دقت مطالعه کنید.</p></div></div>
    <div className="report-cards"><section><h2><FileCheck2/> مدارک مورد نیاز</h2>{requiredEvidence.slice(0,4).map(x=><p key={x}><CheckCircle2/>{x}</p>)}<p><CheckCircle2/>فوروارد پیام‌های اصلی جهت اثبات ادعا</p></section><section><h2><BriefcaseBusiness/> نحوه ارسال مدارک</h2><ol><li>همه مستندات را در یک کانال مجزا و منظم قرار دهید.</li><li>فرم ثبت گزارش را کامل تکمیل کنید.</li><li>لینک کانال و فرم را برای ادمین ثبت بفرستید.</li></ol></section><section><h2><AlertTriangle/> قوانین و تذکرات</h2><p>مدارک ناقص، مخدوش یا ناکافی ممکن است رد شوند.</p><p>مدارک جعلی یا دستکاری‌شده موجب رد فوری پرونده است.</p><p>از توهین، تهدید و مطالب نامرتبط خودداری کنید.</p></section><section className="action-card"><FileText/><h2>فرم ثبت گزارش</h2><p>مسیر رسمی تکمیل فرم و ارسال اطلاعات پرونده</p><RubikaButton href="https://rubika.ir/FuRME_VaSeTeH/BIHFJEHIBCCAFCGI" testId="report-form">ثبت گزارش تخلفات</RubikaButton></section><section className="action-card"><CircleUserRound/><h2>ادمین ثبت گزارش</h2><p>ارسال مستندات و پیگیری فرآیند ثبت گزارش</p><RubikaButton href="https://rubika.ir/FuRME_VaSeTeH/BIHHHHJHEDGGJCGI" testId="report-admin">ارتباط با ادمین ثبت</RubikaButton></section></div>
    <Warning title="توجه مهم">ارسال مدارک به منزله پذیرش ضوابط است. ثبت گزارش به‌تنهایی به معنای اثبات قطعی ادعا یا صدور حکم قضایی نیست.</Warning>
    <div className="double-cta"><RubikaButton href="https://rubika.ir/FuRME_VaSeTeH/BIHFJEHIBCCAFCGI" testId="report-bottom-form">📋 ثبت گزارش تخلفات</RubikaButton><RubikaButton href="https://rubika.ir/FuRME_VaSeTeH/BIHHHHJHEDGGJCGI" testId="report-bottom-admin" secondary>👤 ارتباط با ادمین ثبت</RubikaButton></div>
  </div>;
}

function ContactPage() {
  const links = [
    { icon:<Shield/>, title:'انجمن رسمی روبیکا', href:'https://rubika.ir/AnJvMaN', label:'ورود به انجمن رسمی' },
    { icon:<Landmark/>, title:'هلدینگ واسطه‌گری', href:'https://rubika.ir/HoLDiNG_VaSeTeH', label:'ورود به هلدینگ' },
    { icon:<Users/>, title:'کانون‌ها', href:'https://rubika.ir/AnJvMaN/BIJGAHHBCH', label:'ورود به کانون‌ها' },
    { icon:<CircleUserRound/>, title:'ارتباط با مالک', href:'https://rubika.ir/AcCoUnT_VaSeTeH', label:'آیدی مالک' },
  ];
  return <div className="container page"><Breadcrumb current="مرکز ارتباطی"/><PageHero icon={<Headphones/>} title="مرکز ارتباطی" description="پل ارتباطی شما با مجموعه برای دریافت راهنمایی، پیگیری درخواست‌ها و دسترسی به مسیرهای رسمی."/>
    <div className="contact-grid">{links.map((x,i)=><article key={x.title}>{x.icon}<h2>{x.title}</h2><RubikaButton href={x.href} testId={`contact-${i+1}`} secondary>{x.label}</RubikaButton></article>)}<article><Phone/><h2>تماس با مالک</h2><p dir="ltr">0915 245 0668</p><a className="btn-secondary" href="tel:09152450668" data-testid="contact-phone">تماس با مالک<Phone size={18}/></a></article><article><Mail/><h2>ایمیل پشتیبانی</h2><p dir="ltr">AnJvMaN@gmil.com</p><a className="btn-secondary" href="mailto:AnJvMaN@gmil.com" data-testid="contact-email">ارسال ایمیل<Mail size={18}/></a></article></div>
    <div className="message-promo"><MessagesSquare/><div><h2>پشتیبانی داخل سایت</h2><p>برای ثبت درخواست و مشاهده پاسخ مدیریت، وارد حساب کاربری خود شوید.</p></div><Link className="btn-primary" to="/account" data-testid="contact-account">ورود به پیام‌های من<ArrowLeft size={18}/></Link></div>
  </div>;
}

function LegalPage({ privacy = false }: { privacy?: boolean }) {
  return <div className="container page legal-page"><Breadcrumb current={privacy ? 'حریم خصوصی' : 'شرایط استفاده'}/><PageHero icon={privacy ? <LockKeyhole/> : <BookOpen/>} title={privacy ? 'سیاست حریم خصوصی' : 'شرایط استفاده از وب‌سایت'} description={privacy ? 'نحوه حفاظت از اطلاعات کاربران و حدود استفاده از داده‌ها.' : 'چارچوب استفاده مسئولانه از خدمات و محتوای این وب‌سایت.'}/>
    {privacy ? <><section className="content-card"><h2>اطلاعات حساب و پیام‌ها</h2><p>اطلاعات ثبت‌شده برای ایجاد حساب و پیام‌های پشتیبانی فقط برای ارائه خدمت، پاسخ‌گویی و حفظ سوابق استفاده می‌شوند. هر کاربر فقط به گفتگوهای خود دسترسی دارد.</p></section><section className="content-card"><h2>مدارک حساس</h2><p>مدارک هویتی، شماره کارت و مستندات خصوصی نباید در صفحات عمومی درج شوند. برای ارسال این اطلاعات فقط از مسیرهای رسمی اعلام‌شده استفاده کنید.</p></section><section className="content-card"><h2>امنیت دسترسی</h2><p>گذرواژه‌ها به‌صورت غیرقابل خواندن نگهداری می‌شوند و بخش مدیریت از حساب کاربران جدا و محافظت‌شده است.</p></section></> : <><section className="content-card"><h2>مسئولیت کاربر</h2><p>کاربر موظف است پیش از معامله، هویت، اعتبار و سوابق طرف مقابل را شخصاً بررسی کند. محتوای سایت جایگزین مشاوره یا تصمیم مراجع قانونی نیست.</p></section><section className="content-card"><h2>استفاده صحیح</h2><p>انتشار اطلاعات جعلی، توهین، تهدید، جعل مدرک، دسترسی غیرمجاز و استفاده از خدمات برای آسیب به دیگران ممنوع است.</p></section><section className="content-card"><h2>گزارش‌ها</h2><p>ثبت گزارش به معنای اثبات جرم نیست و نتیجه هر بررسی بر پایه مستندات موجود و در چارچوب داخلی انجمن اعلام می‌شود.</p></section></>}
  </div>;
}

function AuthPanel({ onAuthenticated }: { onAuthenticated: (u: User) => void }) {
  const [mode, setMode] = useState<'login'|'register'>('login');
  const [form, setForm] = useState({ name:'', username:'', password:'' });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const submit = async (e: FormEvent) => { e.preventDefault(); setError(''); if (form.password.length < 8) return setError('رمز عبور باید حداقل ۸ کاراکتر باشد.'); setBusy(true); try { const result = await api<{ user: User }>(`/api/auth/${mode}`, { method:'POST', body:JSON.stringify(form) }); onAuthenticated(result.user); } catch(err) { setError((err as Error).message); } finally { setBusy(false); } };
  return <div className="auth-wrap"><div className="auth-card"><div className="auth-icon"><LockKeyhole/></div><h1>{mode === 'login' ? 'ورود به حساب کاربری' : 'ساخت حساب کاربری'}</h1><p>{mode === 'login' ? 'برای مشاهده پیام‌ها و پیگیری درخواست‌ها وارد شوید.' : 'حساب شما برای ارتباط امن با پشتیبانی استفاده می‌شود.'}</p><div className="auth-tabs"><button className={mode==='login'?'active':''} onClick={()=>{setMode('login');setError('')}} data-testid="login-tab">ورود</button><button className={mode==='register'?'active':''} onClick={()=>{setMode('register');setError('')}} data-testid="register-tab">عضویت</button></div><form onSubmit={submit}>{mode==='register' && <label>نام و نام خانوادگی<input value={form.name} onChange={e=>setForm({...form,name:e.target.value})} required minLength={3} data-testid="auth-name"/></label>}<label>نام کاربری<input dir="ltr" value={form.username} onChange={e=>setForm({...form,username:e.target.value})} required minLength={3} autoComplete="username" data-testid="auth-username"/></label><label>رمز عبور<input dir="ltr" type="password" value={form.password} onChange={e=>setForm({...form,password:e.target.value})} required minLength={8} autoComplete={mode==='login'?'current-password':'new-password'} data-testid="auth-password"/></label>{error && <div className="form-error" data-testid="auth-error">{error}</div>}<button className="btn-primary full" disabled={busy} data-testid="auth-submit">{busy ? 'لطفاً صبر کنید…' : mode==='login'?'ورود به حساب':'ایجاد حساب'}<ArrowLeft size={18}/></button></form></div></div>;
}

function ChatAttachment({url}:{url:string}) {
  const isVideo=/\.(mp4|webm|mov)$/i.test(url);
  return isVideo ? <video className="chat-media" src={url} controls preload="metadata"/> : <a href={url} target="_blank" rel="noreferrer"><img className="chat-media" src={url} alt="پیوست پیام"/></a>;
}

function AccountPage({ user, onAuthenticated }: { user: User | null; onAuthenticated: (u: User) => void }) {
  const [conversations,setConversations]=useState<Conversation[]>([]);const [selected,setSelected]=useState<number|null>(null);const [newMode,setNewMode]=useState(false);
  const [subject,setSubject]=useState(categories[0]);const [body,setBody]=useState('');const [reply,setReply]=useState('');const [attachment,setAttachment]=useState<File|null>(null);
  const [error,setError]=useState('');const [loading,setLoading]=useState(false);const [uploading,setUploading]=useState(false);
  const active=conversations.find(c=>c.id===selected);
  const load=()=>{if(!user)return;setLoading(true);api<{conversations:Conversation[]}>('/api/conversations').then(r=>setConversations(r.conversations)).catch(e=>setError(e.message)).finally(()=>setLoading(false))};
  useEffect(load,[user]);
  const create=async(e:FormEvent)=>{e.preventDefault();if(!body.trim()&&!attachment)return;setError('');setUploading(!!attachment);try{let attachmentUrl='';if(attachment)attachmentUrl=(await uploadChatFile(attachment)).url;const r=await api<{conversation:Conversation}>('/api/conversations',{method:'POST',body:JSON.stringify({subject,body,attachmentUrl})});setConversations([r.conversation,...conversations]);setSelected(r.conversation.id);setNewMode(false);setBody('');setAttachment(null)}catch(err){setError((err as Error).message)}finally{setUploading(false)}};
  const send=async(e:FormEvent)=>{e.preventDefault();if(!selected||(!reply.trim()&&!attachment))return;setError('');setUploading(!!attachment);try{let attachmentUrl='';if(attachment)attachmentUrl=(await uploadChatFile(attachment)).url;const r=await api<{message:Message}>(`/api/conversations/${selected}/messages`,{method:'POST',body:JSON.stringify({body:reply,attachmentUrl})});setConversations(conversations.map(c=>c.id===selected?{...c,messages:[...c.messages,r.message]}:c));setReply('');setAttachment(null)}catch(err){setError((err as Error).message)}finally{setUploading(false)}};
  const picker=(<label className="attach-btn">📎<input type="file" accept="image/*,video/*" onChange={e=>setAttachment(e.target.files?.[0]||null)}/></label>);
  if(!user)return <div className="container page"><Breadcrumb current="حساب کاربری"/><AuthPanel onAuthenticated={onAuthenticated}/></div>;
  return <div className="container page"><Breadcrumb current="پیام‌های من"/><div className="account-head"><div><span>حساب کاربری</span><h1>{user.name}</h1><p dir="ltr">@{user.username}</p></div><button className="btn-primary" onClick={()=>{setNewMode(true);setSelected(null)}}><Plus size={18}/> ارسال پیام جدید</button></div>
    {error&&<div className="form-error">{error}</div>}
    <div className="messenger"><aside><h2>گفتگوهای من</h2>{loading?<div className="message-loading">در حال دریافت گفتگوها…</div>:conversations.length===0?<div className="empty-state"><MessageCircle/><p>هنوز گفتگویی ندارید.</p></div>:conversations.map(c=><button key={c.id} className={selected===c.id?'active':''} onClick={()=>{setSelected(c.id);setNewMode(false)}}><div><strong>{c.subject}</strong><small>{c.messages.at(-1)?.body}</small></div><span className={`status status-${c.status}`}>{c.status}</span>{c.unreadUser>0&&<b>{c.unreadUser}</b>}</button>)}</aside>
    <section className="conversation-pane">{newMode?<form className="new-message-form" onSubmit={create}><h2>ارسال پیام جدید</h2><label>موضوع پیام<select value={subject} onChange={e=>setSubject(e.target.value)}>{categories.map(x=><option key={x}>{x}</option>)}</select></label><label>متن پیام<textarea value={body} onChange={e=>setBody(e.target.value)} rows={7} placeholder="موضوع درخواست را با جزئیات بنویسید…"/></label>{attachment&&<div className="attachment-chip">📎 {attachment.name}</div>}<div className="reply-actions">{picker}<button className="btn-primary" disabled={uploading}><Send size={18}/>{uploading?'در حال ارسال…':'ارسال پیام'}</button></div></form>
    :active?<><div className="conversation-head"><div><h2>{active.subject}</h2><span className={`status status-${active.status}`}>{active.status}</span></div><small>شماره پیگیری: {active.id}</small></div><div className="message-stream">{active.messages.map(m=><div key={m.id} className={`bubble ${m.sender}`}><b>{m.sender==='user'?'شما':'پشتیبانی'}</b>{m.body&&<p>{m.body}</p>}{m.attachmentUrl&&<ChatAttachment url={m.attachmentUrl}/>}<time>{m.createdAt}</time></div>)}</div>{active.status!=='بسته شد'?<form className="reply-box" onSubmit={send}><textarea value={reply} onChange={e=>setReply(e.target.value)} placeholder="پاسخ خود را بنویسید…"/>{attachment&&<span className="attachment-name">📎 {attachment.name}</span>}{picker}<button aria-label="ارسال پاسخ" disabled={uploading}><Send/></button></form>:<div className="closed-note">این گفتگو بسته شده است.</div>}</>:<div className="conversation-placeholder"><MessagesSquare/><h2>یک گفتگو را انتخاب کنید</h2><p>یا با دکمه «ارسال پیام جدید» درخواست تازه‌ای بسازید.</p></div>}</section></div></div>;
}

function AdminPage() {
  const [token,setToken]=useState(()=>localStorage.getItem('admin_token')||'');
  const [login,setLogin]=useState({username:'',password:''});
  const [error,setError]=useState('');
  const [tab,setTab]=useState<'messages'|'brokers'|'notices'>('messages');
  const [conversations,setConversations]=useState<Conversation[]>([]);
  const [brokers,setBrokers]=useState<Broker[]>([]);
  const [notices,setNotices]=useState<Notice[]>([]);
  const [search,setSearch]=useState('');
  const [status,setStatus]=useState('همه');
  const [selected,setSelected]=useState<number|null>(null);
  const [reply,setReply]=useState('');
  const [brokerForm,setBrokerForm]=useState({name:'',handle:''});
  const [noticeForm,setNoticeForm]=useState({title:'',body:''});
  const headers={ 'x-admin-token':token };
  const load=()=>Promise.all([api<{conversations:Conversation[]}>(`/api/admin/conversations?search=${encodeURIComponent(search)}&status=${encodeURIComponent(status)}`,{headers}),api<{brokers:Broker[]}>('/api/admin/brokers',{headers}),api<{notices:Notice[]}>('/api/admin/notices',{headers})]).then(([a,b,n])=>{setConversations(a.conversations);setBrokers(b.brokers);setNotices(n.notices)}).catch(e=>{setError(e.message);if(e.message==='unauthorized'){localStorage.removeItem('admin_token');setToken('')}});
  useEffect(()=>{if(token)load()},[token]);
  const doLogin=async(e:FormEvent)=>{e.preventDefault();setError('');try{const r=await api<{token:string}>('/api/admin/login',{method:'POST',body:JSON.stringify(login)});localStorage.setItem('admin_token',r.token);setToken(r.token)}catch(err){setError((err as Error).message)}};
  const adminReply=async(e:FormEvent)=>{e.preventDefault();if(!selected||!reply.trim())return;try{await api(`/api/admin/conversations/${selected}/messages`,{method:'POST',headers,body:JSON.stringify({body:reply})});setReply('');load()}catch(err){setError((err as Error).message)}};
  const changeStatus=async(id:number,value:string)=>{await api(`/api/admin/conversations/${id}/status`,{method:'PATCH',headers,body:JSON.stringify({status:value})});load()};
  const addBroker=async(e:FormEvent)=>{e.preventDefault();await api('/api/admin/brokers',{method:'POST',headers,body:JSON.stringify(brokerForm)});setBrokerForm({name:'',handle:''});load()};
  const updateBroker=async(b:Broker,patch:Partial<Broker>)=>{await api(`/api/admin/brokers/${b.id}`,{method:'PATCH',headers,body:JSON.stringify({...b,...patch})});load()};
  const deleteBroker=async(id:number)=>{if(!confirm('این واسطه حذف شود؟'))return;await api(`/api/admin/brokers/${id}`,{method:'DELETE',headers});load()};
  const addNotice=async(e:FormEvent)=>{e.preventDefault();await api('/api/admin/notices',{method:'POST',headers,body:JSON.stringify(noticeForm)});setNoticeForm({title:'',body:''});load()};
  const active=conversations.find(c=>c.id===selected);
  if(!token)return <div className="admin-login"><form onSubmit={doLogin}><div className="auth-icon"><Shield/></div><h1>ورود مدیریت</h1><p>این بخش فقط برای مدیران مجاز مجموعه است.</p><label>نام کاربری<input dir="ltr" value={login.username} onChange={e=>setLogin({...login,username:e.target.value})} data-testid="admin-username"/></label><label>رمز عبور<input dir="ltr" type="password" value={login.password} onChange={e=>setLogin({...login,password:e.target.value})} data-testid="admin-password"/></label>{error&&<div className="form-error">{error}</div>}<button className="btn-primary full" data-testid="admin-login">ورود امن<ArrowLeft size={18}/></button><Link to="/">بازگشت به سایت</Link></form></div>;
  return <div className="admin-shell"><aside className="admin-sidebar"><div className="brand"><span>⚜️</span><div><strong>مرکز مدیریت</strong><small>هلدینگ واسطه‌گری</small></div></div><button className={tab==='messages'?'active':''} onClick={()=>setTab('messages')} data-testid="admin-tab-messages"><MessagesSquare/> پیام‌های کاربران</button><button className={tab==='brokers'?'active':''} onClick={()=>setTab('brokers')} data-testid="admin-tab-brokers"><UserCheck/> مدیریت واسطه‌ها</button><button className={tab==='notices'?'active':''} onClick={()=>setTab('notices')} data-testid="admin-tab-notices"><AlertTriangle/> اطلاعیه‌ها</button><button onClick={()=>{localStorage.removeItem('admin_token');setToken('')}} data-testid="admin-logout"><LockKeyhole/> خروج مدیریت</button><Link to="/">مشاهده سایت</Link></aside><main className="admin-main"><header><div><span>داشبورد مدیریت</span><h1>{tab==='messages'?'پیام‌های کاربران':tab==='brokers'?'واسطه‌های ارشد':'اطلاعیه‌های عمومی'}</h1></div><div className="admin-stat"><b>{tab==='messages'?conversations.filter(c=>c.unreadAdmin>0).length:tab==='brokers'?brokers.filter(b=>b.active).length:notices.filter(n=>n.active).length}</b><span>مورد فعال</span></div></header>{error&&<div className="form-error">{error}</div>}
    {tab==='messages'&&<><div className="admin-filters"><label><Search/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="جستجو نام، موضوع یا متن…" data-testid="admin-search"/></label><select value={status} onChange={e=>setStatus(e.target.value)} data-testid="admin-filter"><option>همه</option>{['جدید','در حال بررسی','پاسخ داده شد','در انتظار پاسخ کاربر','بسته شد'].map(x=><option key={x}>{x}</option>)}</select><button onClick={load} data-testid="admin-search-button">جستجو</button></div><div className="admin-messages"><div className="admin-message-list">{conversations.length===0?<div className="empty-state"><MessagesSquare/><p>پیامی یافت نشد.</p></div>:conversations.map(c=><button key={c.id} onClick={()=>setSelected(c.id)} className={selected===c.id?'active':''} data-testid={`admin-conversation-${c.id}`}><div><strong>{c.userName}</strong><span dir="ltr">@{c.username}</span><p>{c.subject}</p></div><span className={`status status-${c.status}`}>{c.status}</span>{c.unreadAdmin>0&&<b>{c.unreadAdmin}</b>}</button>)}</div><section className="admin-chat">{active?<><div className="conversation-head"><div><h2>{active.subject}</h2><p>{active.userName} · <span dir="ltr">@{active.username}</span></p></div><select value={active.status} onChange={e=>changeStatus(active.id,e.target.value)} data-testid="admin-status">{['جدید','در حال بررسی','پاسخ داده شد','در انتظار پاسخ کاربر','بسته شد'].map(x=><option key={x}>{x}</option>)}</select></div><div className="message-stream">{active.messages.map(m=><div key={m.id} className={`bubble ${m.sender}`}><b>{m.sender==='admin'?'مدیریت':active.userName}</b><p>{m.body}</p><time>{m.createdAt}</time></div>)}</div><form className="reply-box" onSubmit={adminReply}><textarea value={reply} onChange={e=>setReply(e.target.value)} placeholder="پاسخ مدیریت…" data-testid="admin-reply-body"/><button data-testid="admin-reply-send"><Send/></button></form></>:<div className="conversation-placeholder"><MessageCircle/><p>یک پیام را انتخاب کنید.</p></div>}</section></div></>}
    {tab==='brokers'&&<div className="manage-grid"><form className="manage-form" onSubmit={addBroker}><h2>افزودن واسطه</h2><label>نام واسطه<input value={brokerForm.name} onChange={e=>setBrokerForm({...brokerForm,name:e.target.value})} required data-testid="broker-name"/></label><label>آیدی روبیکا<input dir="ltr" value={brokerForm.handle} onChange={e=>setBrokerForm({...brokerForm,handle:e.target.value})} required placeholder="@username" data-testid="broker-handle"/></label><button className="btn-primary" data-testid="broker-add"><Plus/> افزودن واسطه</button></form><div className="manage-list">{brokers.map(b=><div key={b.id}><div><strong>{b.name}</strong><code dir="ltr">{b.handle}</code></div><label className="switch"><input type="checkbox" checked={b.active} onChange={e=>updateBroker(b,{active:e.target.checked})} data-testid={`broker-toggle-${b.id}`}/><span/></label><button onClick={()=>{const name=prompt('نام جدید',b.name);const handle=prompt('آیدی جدید',b.handle);if(name&&handle)updateBroker(b,{name,handle})}} data-testid={`broker-edit-${b.id}`}>ویرایش</button><button className="danger" onClick={()=>deleteBroker(b.id)} data-testid={`broker-delete-${b.id}`}>حذف</button></div>)}</div></div>}
    {tab==='notices'&&<div className="manage-grid"><form className="manage-form" onSubmit={addNotice}><h2>اطلاعیه جدید</h2><label>عنوان<input value={noticeForm.title} onChange={e=>setNoticeForm({...noticeForm,title:e.target.value})} required data-testid="notice-title"/></label><label>متن<textarea value={noticeForm.body} onChange={e=>setNoticeForm({...noticeForm,body:e.target.value})} required rows={5} data-testid="notice-body"/></label><button className="btn-primary" data-testid="notice-add"><Plus/> انتشار اطلاعیه</button></form><div className="manage-list">{notices.map(n=><div key={n.id}><div><strong>{n.title}</strong><p>{n.body}</p></div><label className="switch"><input type="checkbox" checked={n.active} onChange={async e=>{await api(`/api/admin/notices/${n.id}`,{method:'PATCH',headers,body:JSON.stringify({active:e.target.checked})});load()}} data-testid={`notice-toggle-${n.id}`}/><span/></label></div>)}</div></div>}
  </main></div>;
}

function App() {
  const [user,setUser]=useState<User|null>(null);
  const [notices,setNotices]=useState<Notice[]>([]);
  useEffect(()=>{api<{user:User|null}>('/api/auth/me').then(r=>setUser(r.user)).catch(()=>{});api<{notices:Notice[]}>('/api/notices').then(r=>setNotices(r.notices)).catch(()=>{});},[]);
  const logout=()=>api('/api/auth/logout',{method:'POST'}).finally(()=>setUser(null));
  return <BrowserRouter><Routes><Route path="/admin" element={<AdminCenter/>}/><Route path="*" element={<Layout user={user} onLogout={logout}><Routes><Route path="/" element={<HomePage notices={notices}/>}/><Route path="/about" element={<AboutPage/>}/><Route path="/brokers" element={<BrokersPage/>}/><Route path="/alliance" element={<AlliancePage/>}/><Route path="/membership" element={<MembershipPage/>}/><Route path="/chats" element={<ChatsPage/>}/><Route path="/rules" element={<RulesPage/>}/><Route path="/reports" element={<ReportsPage/>}/><Route path="/verification" element={<VerificationPage/>}/><Route path="/employee-verification" element={<EmployeeVerificationPage/>}/><Route path="/verification/report" element={<DiscrepancyReportPage/>}/><Route path="/verify/:code" element={<PartnerProfilePage/>}/><Route path="/contact" element={<ContactPage/>}/><Route path="/terms" element={<LegalPage/>}/><Route path="/privacy" element={<LegalPage privacy/>}/><Route path="/account" element={<AccountPage user={user} onAuthenticated={setUser}/>}/><Route path="*" element={<div className="container not-found"><h1>صفحه پیدا نشد</h1><Link to="/" className="btn-primary">بازگشت به صفحه اصلی</Link></div>}/></Routes></Layout>}/></Routes></BrowserRouter>;
}

export default App;
